package eu.ase.ro.damappfirebase;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damappfirebase.util.Callback;
import eu.ase.ro.damappfirebase.util.Student;


public class FirebaseService {

    public static final String STUDENT_REFERENCE = "students";
    private final DatabaseReference reference;

    private static FirebaseService firebaseService;

    private FirebaseService() {
        reference = FirebaseDatabase.getInstance().getReference(STUDENT_REFERENCE);
    }

    public static FirebaseService getInstance() {
        if (firebaseService == null) {
            synchronized (FirebaseService.class) {
                if (firebaseService == null) {
                    firebaseService = new FirebaseService();
                }
            }
        }
        return firebaseService;
    }

    public void insert(Student student) {
        if (student == null || (student.getId() != null && !student.getId().trim().isEmpty())) {
            return;
        }
        String id = reference.push().getKey();
        student.setId(id);
        reference.child(student.getId()).setValue(student);
    }

    public void update(Student student) {
        if (student == null || student.getId() == null || student.getId().trim().isEmpty()) {
            return;
        }
        reference.child(student.getId()).setValue(student);
    }

    public void delete(Student student) {
        if (student == null || student.getId() == null || student.getId().trim().isEmpty()) {
            return;
        }
        reference.child(student.getId()).removeValue();
    }

    public void attachDataChangeEventListener(Callback<List<Student>> callback) {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Student> students = new ArrayList<>();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Student student = data.getValue(Student.class);
                    if (student != null) {
                        students.add(student);
                    }
                }
                callback.runResultOnUiThread(students);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseService", "Data is not available");
            }
        });
    }
}