package eu.ase.ro.damappfirebase.util;

public interface Callback<R> {
    void runResultOnUiThread(R result);
}
