package com.example.damapp.model;

public enum StudyType {
    FULL_TIME, DISTANCE
}
