package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.damapp.model.Student;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> launcher;
    private ActivityResultLauncher<Intent> profileLauncher;

    private FloatingActionButton fabAdd;
    private Button btnAddProfile;
    private ListView lvStudents;

    private List<Student> students = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
    }

    private void initComponents() {
        //inregistrare lansator
        ActivityResultCallback<ActivityResult> callback = getStudentCallback();
        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                callback);

        fabAdd = findViewById(R.id.main_fab_add);
        fabAdd.setOnClickListener(getAddListener());
        //unde se scrie findviewbyid pentru listview
        //se initializeaza si Adapterul
        lvStudents = findViewById(R.id.main_lv_students);
        ArrayAdapter<Student> adapter =
                new ArrayAdapter<>(
                        getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        students
                );
        //atasare adapter de listview
        lvStudents.setAdapter(adapter);

        //exercitiu rezolvare
        ActivityResultCallback<ActivityResult> profileCallback = getProfileCallback();
        profileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), profileCallback);
        btnAddProfile = findViewById(R.id.main_btn_add_profile);
        btnAddProfile.setOnClickListener(getAddProfileClick());
    }

    private View.OnClickListener getAddProfileClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                profileLauncher.launch(intent);
            }
        };
    }

    private ActivityResultCallback<ActivityResult> getProfileCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    String name = result.getData().getStringExtra(ProfileActivity.NAME_KEY);
                    Toast.makeText(getApplicationContext(), getString(R.string.main_welcome_template, name), Toast.LENGTH_SHORT).show();
                }
            }
        };
    }

    private View.OnClickListener getAddListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aici facem pasul 1 din schema
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                launcher.launch(intent);
            }
        };
    }

    private ActivityResultCallback<ActivityResult> getStudentCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                //este pasul 4 din schema
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
//                    String info = result.getData().getStringExtra(AddActivity.ADD_STUDENT_KEY);
                    Student student = (Student) result.getData()
                            .getSerializableExtra(
                                    AddActivity.ADD_STUDENT_KEY);
                    Toast.makeText(getApplicationContext(),
                            student.toString(),
                            Toast.LENGTH_LONG).show();

                    //populez colectia de studenti
                    students.add(student);
                    //notificare adapter pentru redesenare
                    ArrayAdapter<Student> adapter
                            = (ArrayAdapter<Student>)
                            lvStudents.getAdapter();
                    adapter.notifyDataSetChanged();
                }
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.main_about) {
            //deschidem activitatea about
            Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}