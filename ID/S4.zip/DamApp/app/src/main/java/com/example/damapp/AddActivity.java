package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatSpinner;

import com.example.damapp.model.Student;
import com.example.damapp.model.StudyType;
import com.example.damapp.util.DateConverter;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_STUDENT_KEY = "ADD_STUDENT_KEY";
    private Intent intent;

    private AppCompatButton btnSave;
    private TextInputEditText tietName;
    private TextInputEditText tietEnrollmentDate;
    private AppCompatSpinner spnFaculty;
    private RadioGroup rgStudyType;

    private Student student = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        initComponents();
        if (intent.hasExtra(ADD_STUDENT_KEY)) {
            loadComponentsFromObject();
        }
    }

    private void loadComponentsFromObject() {
        student = (Student) intent.getSerializableExtra(ADD_STUDENT_KEY);
        if (student == null) {
            return;
        }
        //setam numele studentului pe ecran
        tietName.setText(student.getName());
        //setam data de inscriere pe ecran
        tietEnrollmentDate.setText(DateConverter.fromDate(student.getEnrollmentDate()));
        //setam forma de invatamant
        if (StudyType.DISTANCE == student.getStudyType()) {
            //trebuie sa selectam radio button cu numele distance
            rgStudyType.check(R.id.add_rb_distance);
        } else {
            //trebuie sa selectam radio button cu numele full time
            rgStudyType.check(R.id.add_rb_full_time);
        }
        //setam facultatea
        ArrayAdapter<CharSequence> adapter = (ArrayAdapter<CharSequence>) spnFaculty.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            String item = adapter.getItem(i).toString();
            if (student.getFaculty().equals(item)) {
                spnFaculty.setSelection(i);
                break;
            }
        }
    }

    private void initComponents() {
        //pasul 2 din schema
        intent = getIntent();

        btnSave = findViewById(R.id.add_btn_save);
        btnSave.setOnClickListener(getSaveListener());

        tietName = findViewById(R.id.add_tiet_name);
        tietEnrollmentDate = findViewById(R.id.add_tiet_enrollment_date);
        spnFaculty = findViewById(R.id.add_spn_faculties);
        rgStudyType = findViewById(R.id.add_rg_study_type);
    }

    private View.OnClickListener getSaveListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValid()) {
                    //construiesc student
                    buildStudent();
                    //aici facem pasul 3 din schema
                    intent.putExtra(ADD_STUDENT_KEY, student);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private void buildStudent() {
        String name = tietName.getText().toString();
        Date enrollmentDate = DateConverter.toDate(tietEnrollmentDate.getText().toString());
        String faculty = (String) spnFaculty.getSelectedItem();
        StudyType studyType = rgStudyType.getCheckedRadioButtonId() == R.id.add_rb_full_time
                ? StudyType.FULL_TIME : StudyType.DISTANCE;

        if (student == null) {
            //studentul lipseste deci suntem pe scenariul in care s-a apasat pe + si nu pe un element din listview ca sa facem editare
            student = new Student(name, enrollmentDate, faculty, studyType);
        }

        //suntem pe scenariul de editare cand studentul nu este null atunci facem update ca sa nu pierdem id-ul bazei de date,
        // in cazul in care trimitem fara id-ul vechi nu se realizeaza update in baza de date
        student.setName(name);
        student.setFaculty(faculty);
        student.setEnrollmentDate(enrollmentDate);
        student.setStudyType(studyType);
    }

    private boolean isValid() {
        if (tietName.getText() == null || tietName.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(), R.string.invalid_name_minim_3_characters, Toast.LENGTH_LONG).show();
            return false;
        }
        //dd-MM-yyyy
        if (tietEnrollmentDate.getText() == null || DateConverter.toDate(tietEnrollmentDate.getText().toString()) == null) {
            Toast.makeText(getApplicationContext(), R.string.invalid_enrollment_date_accepted_dd_mm_yyyy, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}