package com.example.damapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class ProfileActivity extends AppCompatActivity {

    public static final String NAME_KEY = "NAME_KEY";

    private TextInputEditText tietName;
    private Button btnSave;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        initComponent();
        intent = getIntent();
    }

    private void initComponent() {
        tietName = findViewById(R.id.profile_tiet_name);
        btnSave = findViewById(R.id.profile_btn_save);

        btnSave.setOnClickListener(getSaveListener());
    }

    private View.OnClickListener getSaveListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isValid()){
                    String name = tietName.getText().toString();
                    intent.putExtra(NAME_KEY, name);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private boolean isValid() {
        if(tietName.getText() == null || tietName.getText().toString().trim().length() < 3){
            Toast.makeText(getApplicationContext(), R.string.profile_invalid_name_minim_3_characters, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}