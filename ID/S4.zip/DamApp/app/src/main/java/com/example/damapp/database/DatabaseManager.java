package com.example.damapp.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.damapp.model.Student;
import com.example.damapp.util.DateConverter;

@Database(entities = {Student.class}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class DatabaseManager extends RoomDatabase {

    private static DatabaseManager databaseManager;

    public static DatabaseManager getInstance(Context context) {
        if (databaseManager == null) {
            databaseManager = Room.databaseBuilder(context, DatabaseManager.class, "dam_db")
                    .fallbackToDestructiveMigration()
                    //.allowMainThreadQueries() - este o metoda utilizata doar in teste
                    .build();
        }
        return databaseManager;
    }

    public abstract StudentDao getStudentDao();
}
