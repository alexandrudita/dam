package com.example.damapp.database;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.example.damapp.model.Student;
import com.example.damapp.util.Callback;

import java.util.List;

public class StudentService {

    private final StudentDao studentDao;
    private final Handler handler = new Handler(Looper.getMainLooper());

    public StudentService(Context context) {
        this.studentDao = DatabaseManager.getInstance(context).getStudentDao();
    }

    public void insert(Student student, Callback<Student> callback) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                if (student == null || student.getId() > 0) {
                    handler.post(() -> callback.runResultOnUiThread(null));
                    return;
                }

                long id = studentDao.insert(student);
                if (id <= 0) {
                    handler.post(() -> callback.runResultOnUiThread(null));
                    return;
                }
                student.setId(id);
                handler.post(() -> callback.runResultOnUiThread(student));
            }
        };
        thread.start();
    }

    public void getAll(Callback<List<Student>> callback) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                List<Student> students = studentDao.getAll();
                handler.post(() -> callback.runResultOnUiThread(students));
            }
        };
        thread.start();
    }

    public void update(Student student, Callback<Student> callback) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                if (student == null || student.getId() <= 0) {
                    handler.post(() -> callback.runResultOnUiThread(null));
                    return;
                }
                int count = studentDao.update(student);
                if (count < 1) {
                    handler.post(() -> callback.runResultOnUiThread(null));
                    return;
                }
                handler.post(() -> callback.runResultOnUiThread(student));
            }
        };
        thread.start();
    }

    public void delete(Student student, Callback<Boolean> callback) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                if (student == null || student.getId() <= 0) {
                    handler.post(() -> callback.runResultOnUiThread(false));
                    return;
                }
                int count = studentDao.delete(student);
                if (count < 1) {
                    handler.post(() -> callback.runResultOnUiThread(false));
                    return;
                }
                handler.post(() -> callback.runResultOnUiThread(true));
            }
        };
        thread.start();
    }
}
