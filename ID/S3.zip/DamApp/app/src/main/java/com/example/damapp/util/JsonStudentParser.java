package com.example.damapp.util;

import androidx.annotation.NonNull;

import com.example.damapp.model.Student;
import com.example.damapp.model.StudyType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class JsonStudentParser {

    private static final String NAME = "name";
    private static final String FACULTY = "faculty";
    private static final String STUDY_TYPE = "studyType";
    private static final String ENROLLMENT_DATE = "enrollmentDate";

    public static List<Student> fromJson(String json){
        try {
            List<Student> results = new ArrayList<>();
            JSONArray array = new JSONArray(json);
            for(int i=0;i<array.length();i++){
                JSONObject object = array.getJSONObject(i);
                Student student = getStudentFromJson(object);
                results.add(student);
            }
            return results;
        } catch (JSONException e) {
            return  new ArrayList<>();
        }
    }

    @NonNull
    private static Student getStudentFromJson(JSONObject object) throws JSONException {
        String name = object.getString(NAME);
        String faculty = object.getString(FACULTY);
        StudyType studyType = StudyType.valueOf(object.getString(STUDY_TYPE));
        Date enrollmentDate = DateConverter.toDate(object.getString(ENROLLMENT_DATE));
        return new Student(name, enrollmentDate, faculty, studyType);
    }
}

