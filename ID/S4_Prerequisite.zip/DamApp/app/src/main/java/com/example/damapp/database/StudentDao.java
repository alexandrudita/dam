package com.example.damapp.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.damapp.model.Student;

import java.util.List;

@Dao
public interface StudentDao {

    long insert(Student student);

    List<Student> getAll();

    int update(Student student);

    int delete(Student student);

}
