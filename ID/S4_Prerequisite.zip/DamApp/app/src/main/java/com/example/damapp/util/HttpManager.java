package com.example.damapp.util;

import android.util.Log;

import androidx.annotation.NonNull;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpManager {

    private final String url;
    private HttpURLConnection connection;
    private InputStream inputStream;
    private InputStreamReader inputStreamReader;
    private BufferedReader bufferedReader;

    public HttpManager(String url) {
        this.url = url;
    }

    public String process() {
        try {
            return getResultFromHttp();
        } catch (IOException e) {
            Log.e("HttpManager", "Connection failed");
        } finally {
            closeConnections();
        }

        return null;
    }

    @NonNull
    private String getResultFromHttp() throws IOException {
        connection = (HttpURLConnection) new URL(url).openConnection();
        inputStream = connection.getInputStream();
        inputStreamReader = new InputStreamReader(inputStream);
        bufferedReader = new BufferedReader(inputStreamReader);
        String line;
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null) {
            result.append(line);
        }
        return result.toString();
    }

    private void closeConnections() {
        try {
            bufferedReader.close();
        } catch (IOException e) {
            Log.e("HttpManager", "buffered closed failed");
        }
        try {
            inputStreamReader.close();
        } catch (IOException e) {
            Log.e("HttpManager", "inputStreamReader closed failed");
        }
        try {
            inputStream.close();
        } catch (IOException e) {
            Log.e("HttpManager", "inputStream closed failed");
        }
        connection.disconnect();
    }
}
