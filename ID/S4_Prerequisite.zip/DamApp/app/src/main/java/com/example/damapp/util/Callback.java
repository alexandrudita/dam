package com.example.damapp.util;

public interface Callback<R>{
    void runResultOnUiThread(R result);
}
