package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class AddActivity extends AppCompatActivity {

    public static final String STUDENT_KEY = "studentKey";

    private Button btnSave;

    private TextInputEditText tietName;
    private Spinner spnFaculty;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        //facem pasul 2 din schema
        intent = getIntent();
        //legam de componentele vizuale din activity_add.xml
        tietName = findViewById(R.id.add_tiet_name);
        spnFaculty = findViewById(R.id.add_spn_faculty);
        btnSave = findViewById(R.id.add_btn_save);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aici suntem cand dam pe save
                String name = tietName.getText().toString();
                String faculty = spnFaculty.getSelectedItem().toString();
                Student student = new Student(name, faculty);
                //facem pasul 3 din schema
                intent.putExtra(STUDENT_KEY, student);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}