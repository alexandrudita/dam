package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String STUDENTS_URL = "https://www.npoint.io/docs/08a77cd7ca684ac83e08";


    private Button btnAddStudent;
    private ListView lvStudents;
    private List<Student> students = new ArrayList<>();
    private ActivityResultLauncher<Intent> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //TREBUIE sa inregistrez DOAR in onCreate
        ActivityResultCallback<ActivityResult> callback =
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //aici suntem in pasul 4 din schema.
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Student student = (Student) result.getData()
                                    .getSerializableExtra(AddActivity.STUDENT_KEY);
                            //----------------------------------------------------------
                            //de aici facem doar ce tine de aplicatie
                            students.add(student);
                            //notificare adapter ca am adaugat alt student
                            ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
                            adapter.notifyDataSetChanged();
                        }
                    }
                };
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                callback
        );
        //initializarea butonului cu cel din activity_main.xml
        lvStudents = findViewById(R.id.main_lv_students);
        ArrayAdapter<Student> adapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                students
        );
        lvStudents.setAdapter(adapter);
        btnAddStudent = findViewById(R.id.main_btn_add_student);
        btnAddStudent.setOnClickListener(

                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //ajungem cand dam click pe buton
                        //facem pasul 1 din schema
                        Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                        launcher.launch(intent);
                    }
                }

        );
    }
}