package eu.ase.ro.damidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class AnaAreMereActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ana_are_mere);

        Log.i("AnaAreMere", "onCreate call");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i("AnaAreMere", "onPause call");
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.i("AnaAreMere", "onResume call");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.i("AnaAreMere", "onDestroy call");
    }
}