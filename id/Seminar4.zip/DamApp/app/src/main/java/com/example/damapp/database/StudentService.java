package com.example.damapp.database;

import android.content.Context;

import com.example.damapp.Student;
import com.example.damapp.network.AsyncTaskRunner;
import com.example.damapp.network.Callback;

import java.util.List;
import java.util.concurrent.Callable;

public class StudentService {

    private final AsyncTaskRunner asyncTaskRunner;
    private final StudentDao studentDao;

    public StudentService(Context context) {
        asyncTaskRunner = new AsyncTaskRunner();
        studentDao = DatabaseManager.getInstance(context).getStudentDao();
    }

    public void insert(Student student, Callback<Student> callback) {

        Callable<Student> callable = new Callable<Student>() {
            @Override
            public Student call() throws Exception {
                if (student.getId() > 0) {
                    return null;
                }
                long id = studentDao.insert(student);
                if (id > 0) {
                    student.setId(id);
                    return student;
                }

                return null;
            }
        };
        asyncTaskRunner.executeAsync(callable, callback);
    }

    public void getAll(Callback<List<Student>> callback) {

        Callable<List<Student>> callable = new Callable<List<Student>>() {
            @Override
            public List<Student> call() throws Exception {
                return studentDao.getAll();
            }
        };
        asyncTaskRunner.executeAsync(callable, callback);
    }

    public void delete(Student student, Callback<Boolean> callback) {

        Callable<Boolean> callable = new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                if (student.getId() == 0) {
                    return false;
                }
                int count = studentDao.delete(student);
                return count == 1;
            }
        };
        asyncTaskRunner.executeAsync(callable, callback);
    }

    public void update(Student student, Callback<Student> callback) {

        Callable<Student> callable = new Callable<Student>() {
            @Override
            public Student call() throws Exception {
                if (student.getId() == 0) {
                    return null;
                }
                int count = studentDao.update(student);
                if (count != 1) {
                    return null;
                }
                return student;
            }
        };
        asyncTaskRunner.executeAsync(callable, callback);
    }
}
