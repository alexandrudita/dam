package com.example.damapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class StudentParser {

    public static List<Student> fromJson(String json){
        try {
            JSONArray array =new JSONArray(json);
            List<Student> results = new ArrayList<>();
            for(int i = 0;i<array.length();i++){
                //citim din json array elementul de ep pozitia i
                JSONObject object = array.getJSONObject(i);
                //citim numele si facultatea studentului
                String name = object.getString("name");
                String faculty = object.getString("faculty");
                //construim obiectul student
                Student student = new Student(name, faculty);
                results.add(student);
            }
            return results;
        } catch (JSONException e) {
            return new ArrayList<>();
        }
    }
}
