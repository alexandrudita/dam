package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.damapp.database.StudentService;
import com.example.damapp.network.AsyncTaskRunner;
import com.example.damapp.network.Callback;
import com.example.damapp.network.HttpManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String STUDENTS_URL = "https://www.npoint.io/docs/08a77cd7ca684ac83e08";
    public static final String SELECTED_POSITION_FOR_UPDATE = "position";
    public static final String ACTION = "action";
    public static final String UPDATE_ACTION = "update";


    private Button btnAddStudent;
    private ListView lvStudents;
    private List<Student> students = new ArrayList<>();
    private ActivityResultLauncher<Intent> launcher;

    private AsyncTaskRunner asyncTaskRunner;
    private StudentService studentService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        asyncTaskRunner = new AsyncTaskRunner();
        studentService = new StudentService(getApplicationContext());

        //TREBUIE sa inregistrez DOAR in onCreate
        ActivityResultCallback<ActivityResult> callback =
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //aici suntem in pasul 4 din schema.
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Student student = (Student) result.getData()
                                    .getSerializableExtra(AddActivity.STUDENT_KEY);
                            if (UPDATE_ACTION.equals(result.getData().getStringExtra(ACTION))) {
                                //sunt in modul update
                                //citim din intent positia trimisa la apasarea pe elementul din listview
                                int position = result.getData().getIntExtra(SELECTED_POSITION_FOR_UPDATE, 0);
                                studentService.update(student, updateCallback(position));
                            } else {
                                //suntem in modul insert
                                studentService.insert(student, insertCallback());
                            }
                            //----------------------------------------------------------
                        }
                    }
                };
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                callback
        );
        //initializarea butonului cu cel din activity_main.xml
        lvStudents = findViewById(R.id.main_lv_students);
        ArrayAdapter<Student> adapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                students
        );
        lvStudents.setAdapter(adapter);
        btnAddStudent = findViewById(R.id.main_btn_add_student);
        btnAddStudent.setOnClickListener(

                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //ajungem cand dam click pe buton
                        //facem pasul 1 din schema
                        Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                        launcher.launch(intent);
                    }
                }

        );
        lvStudents.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                studentService.delete(students.get(i), deleteCallback(i));
                return true;
            }
        });
        //la click pe element se deschide activitatea de adaugare in care se va incarca studentul selectat
        lvStudents.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                //atasam studentul trimis pentru modificare
                intent.putExtra(AddActivity.STUDENT_KEY, students.get(i));
                //trimtem pozitia curenta ca sas tim pe cine modificam in listview dupa revenirea din activitatea de adaugare
                intent.putExtra(SELECTED_POSITION_FOR_UPDATE, i);
                //trimite actiunea de update astfel incat la revenirea in ActivityResultCallback sa facem diferenta daca e insert sau update
                intent.putExtra(ACTION, UPDATE_ACTION);
                launcher.launch(intent);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        loadFromHttp();
        //studenti din baza de date;
        studentService.getAll(getAllCallback());
    }

    //------------ retea -----------------------------------------
    private void loadFromHttp() {
        HttpManager callable = new HttpManager(STUDENTS_URL);
        asyncTaskRunner.executeAsync(callable, new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                List<Student> tempStud = StudentParser.fromJson(result);
                students.addAll(tempStud);
                //notificare adapter ca am adaugat alt student
                ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
                adapter.notifyDataSetChanged();
            }
        });
    }

    //---------------------------baze de date---------------------------------

    private Callback<Student> insertCallback() {
        return new Callback<Student>() {
            @Override
            public void runResultOnUiThread(Student result) {
                if (result != null) {
                    //de aici facem doar ce tine de aplicatie
                    students.add(result);
                    //notificare adapter ca am adaugat alt student
                    ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
                    adapter.notifyDataSetChanged();
                }
            }
        };
    }

    private Callback<List<Student>> getAllCallback() {
        return new Callback<List<Student>>() {
            @Override
            public void runResultOnUiThread(List<Student> result) {
                if (result != null && result.size() > 0) {
                    //de aici facem doar ce tine de aplicatie
                    students.addAll(result);
                    //notificare adapter ca am adaugat alt student
                    ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
                    adapter.notifyDataSetChanged();
                }
            }
        };
    }

    private Callback<Boolean> deleteCallback(int position) {
        return new Callback<Boolean>() {
            @Override
            public void runResultOnUiThread(Boolean result) {
                if (result) {
                    //stergem studentul din lista astfel incat sa afisam si pe ecran stergerea din baza de date
                    students.remove(position);
                    //notificare adapter ca am adaugat alt student
                    ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
                    adapter.notifyDataSetChanged();
                }
            }
        };
    }

    private Callback<Student> updateCallback(int position) {
        return new Callback<Student>() {
            @Override
            public void runResultOnUiThread(Student result) {
                if (result != null) {
                    //modificam valorile studentului de pozitia position in lista
                    students.get(position).setName(result.getName());
                    students.get(position).setFaculty(result.getFaculty());
                    //notificare adapter ca am adaugat alt student
                    ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
                    adapter.notifyDataSetChanged();
                }
            }
        };
    }
}