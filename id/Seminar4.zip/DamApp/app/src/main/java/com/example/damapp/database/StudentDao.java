package com.example.damapp.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.damapp.Student;

import java.util.List;

@Dao
public interface StudentDao {

    @Insert
    long insert(Student student);
    @Query("select * from students")
    List<Student> getAll();
    @Update
    int update(Student student);
    @Delete
    int delete(Student student);

}
