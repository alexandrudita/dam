package eu.ase.ro.dammenuapp;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configNavigation();
        navView = findViewById(R.id.nav_view);
        navView.setNavigationItemSelectedListener(getSelectedItemEvent());
    }

    private NavigationView.OnNavigationItemSelectedListener
    getSelectedItemEvent() {
        return new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean
            onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.nav_home) {
                    Toast.makeText(getApplicationContext(),
                                    R.string.home_message,
                                    Toast.LENGTH_SHORT)
                            .show();
                }

                if (item.getItemId() == R.id.nav_contact) {
                    Toast.makeText(getApplicationContext(),
                                    R.string.contact_message,
                                    Toast.LENGTH_SHORT)
                            .show();
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        };
    }

    private void configNavigation() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(
                R.menu.main_menu,
                menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.main_settings) {
            Toast.makeText(getApplicationContext(),
                            R.string.settings_message,
                            Toast.LENGTH_LONG)
                    .show();
        }
        return super.onOptionsItemSelected(item);
    }
}