package eu.ase.ro.damapproom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapproom.async.Callback;
import eu.ase.ro.damapproom.database.ExpenseService;
import eu.ase.ro.damapproom.util.Expense;
import eu.ase.ro.damapproom.util.ExpenseAdapter;

public class MainActivity extends AppCompatActivity {

    private ListView lvExpenses;
    private FloatingActionButton fabAddExpense;

    private List<Expense> expenses = new ArrayList<>();
    private ActivityResultLauncher<Intent> addExpenseLauncher;

    private ExpenseService expenseService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expenseService = new ExpenseService(getApplicationContext());
        initComponents();
        addExpenseLauncher = getAddExpenseLauncher();
        //selectam toate cheltuielile din baza de adte
        expenseService.getAll(getAllCallback());
    }

    private Callback<List<Expense>> getAllCallback() {
        return new Callback<List<Expense>>() {
            @Override
            public void runResultOnUiThread(List<Expense> result) {
                //suntem in thread-ul activitatii principale
                expenses.addAll(result);
                notifyAdapter();
            }
        };
    }

    private ActivityResultLauncher<Intent> getAddExpenseLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddExpenseActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddExpenseActivityResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result != null && result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Expense expense = (Expense) result.getData().getSerializableExtra(AddExpenseActivity.EXPENSE_KEY);
                    expenseService.insert(expense, getInsertCallback());
                }
            }
        };
    }

    private Callback<Expense> getInsertCallback() {
        return new Callback<Expense>() {
            @Override
            public void runResultOnUiThread(Expense expense) {
                //aici ma aflu pe callbackul de la inser, adica in main thread. am raspunde primit de la baza de date
                if (expense != null) {
                    expenses.add(expense);
                    notifyAdapter();
                }
            }
        };
    }

    private void initComponents() {
        lvExpenses = findViewById(R.id.main_lv_expenses);
        fabAddExpense = findViewById(R.id.main_fab_add_expense);
        addAdapter();
        fabAddExpense.setOnClickListener(addExpenseEventListener());
    }

    private View.OnClickListener addExpenseEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                addExpenseLauncher.launch(intent);
            }
        };
    }

    private void addAdapter() {
        ExpenseAdapter adapter = new ExpenseAdapter(getApplicationContext(), R.layout.lv_expense_row,
                expenses, getLayoutInflater());
        lvExpenses.setAdapter(adapter);
    }

    private void notifyAdapter() {
        ExpenseAdapter adapter = (ExpenseAdapter) lvExpenses.getAdapter();
        adapter.notifyDataSetChanged();
    }
}