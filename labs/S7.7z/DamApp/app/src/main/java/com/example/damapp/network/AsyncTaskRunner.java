package com.example.damapp.network;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncTaskRunner {

    private final Handler handler =
            new Handler(Looper.getMainLooper());
    private final ExecutorService executor =
            Executors.newCachedThreadPool();

    public <R> void executeAsync(
            Callable<R> asyncOperation,
            Callback<R> mainThreadOperation) {
        //ce thread am???? -> MainThread
        try {
            executor.execute(runAsyncOperation(asyncOperation, mainThreadOperation));
        } catch (Exception e) {
            Log.i("AsyncTaskRunner", "execute call failed " +
                    e.getMessage());
        }
    }

    @NonNull
    private <R> Runnable runAsyncOperation(Callable<R> asyncOperation, Callback<R> mainThreadOperation) {
        return new Runnable() {
            @Override
            public void run() {
                //aici ma aflu pe un alt thread
                //paralel cu cel principal
                try {
                    R result = asyncOperation.call();
                    //trimit datele catre handler
                    handler.post(runMainThreadOperation(result, mainThreadOperation));
                } catch (Exception e) {
                    Log.e("AsyncTaskRunner",
                            "async operation call failed "
                                    + e.getMessage());
                }
            }
        };
    }

    @NonNull
    private <R> Runnable runMainThreadOperation(R result, Callback<R> mainThreadOperation) {
        return new Runnable() {
            @Override
            public void run() {
                //aici o sa fie executata metoda run
                //de catre thread principal
                mainThreadOperation.runResultOnUiThread(result);
            }
        };
    }

}
