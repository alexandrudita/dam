package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.damapp.model.Student;
import com.example.damapp.network.AsyncTaskRunner;
import com.example.damapp.network.Callback;
import com.example.damapp.network.HttpManager;
import com.example.damapp.util.StudentAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> launcher;

    private FloatingActionButton fabAdd;
    private ListView lvStudents;

    private List<Student> students = new ArrayList<>();

    private static final String HTTP_STUDENTS_URL =
            "https://api.npoint.io/e9d291ba16f56a5023ba";
    private Handler handler = new Handler(Looper.getMainLooper());

    private final AsyncTaskRunner asyncTaskRunner = new AsyncTaskRunner();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();

        //deschidere conexiune + preluare info din url
//        Thread thread = new Thread(){
//            @Override
//            public void run() {
//                //aici ma aflu pe alt fir de executie, paralel cu cel principal
//                //atentie!!! nu puteti accesa variabilele globale de tip componente
//                // din MainActivity, exceptie face obiectul Handler.
//                HttpManager manager =
//                        new HttpManager(HTTP_STUDENTS_URL);
//                String result = manager.call();
//                //trimitem datele catre thread principal prin handler
//                handler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        //este apelata in MainThread, adica
//                        //aici pot accesa orice variabila de tip componenta vizuala
//                        //sau elemente specifice lucrului cu activitati
//                        Toast.makeText(getApplicationContext(),
//                                result,
//                                Toast.LENGTH_LONG).show();
//                    }
//                });
//
//            }
//        };
//        thread.start();
//
        //folosim executor service
//        ExecutorService executor = Executors.newCachedThreadPool();
//        executor.execute(new Runnable() {
//            @Override
//            public void run() {
//                //aici ma aflu pe alt fir de executie, paralel cu cel principal
//                //atentie!!! nu puteti accesa variabilele globale de tip componente
//                // din MainActivity, exceptie face obiectul Handler.
//                HttpManager manager =
//                        new HttpManager(HTTP_STUDENTS_URL);
//                String result = manager.call();
//                //trimitem datele catre thread principal prin handler
//                handler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        //este apelata in MainThread, adica
//                        //aici pot accesa orice variabila de tip componenta vizuala
//                        //sau elemente specifice lucrului cu activitati
//                        Toast.makeText(getApplicationContext(),
//                                        result,
//                                        Toast.LENGTH_LONG)
//                                .show();
//                    }
//                });
//            }
//        });

        //folosim async task runner

        Callable<String> asyncOperation = new HttpManager(HTTP_STUDENTS_URL);
        Callback<String> mainThreadOperation = new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                Toast.makeText(getApplicationContext(),
                                result,
                                Toast.LENGTH_LONG)
                        .show();
            }
        };
        asyncTaskRunner.executeAsync(asyncOperation,
                mainThreadOperation);

    }

    private void initComponents() {
        //inregistrare lansator
        ActivityResultCallback<ActivityResult> callback = getStudentCallback();
        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                callback);

        fabAdd = findViewById(R.id.main_fab_add);
        fabAdd.setOnClickListener(getAddListener());
        //unde se scrie findviewbyid pentru listview
        //se initializeaza si Adapterul
        lvStudents = findViewById(R.id.main_lv_students);
//        ArrayAdapter<Student> adapter =
//                new ArrayAdapter<>(
//                        getApplicationContext(),
//                        android.R.layout.simple_list_item_1,
//                        students
//                );

        StudentAdapter adapter = new
                StudentAdapter(
                getApplicationContext(),
                R.layout.lv_item,
                students,
                getLayoutInflater()
        );
        //atasare adapter de listview
        lvStudents.setAdapter(adapter);
    }

    private View.OnClickListener getAddListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aici facem pasul 1 din schema
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                launcher.launch(intent);
            }
        };
    }

    private ActivityResultCallback<ActivityResult> getStudentCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                //este pasul 4 din schema
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
//                    String info = result.getData().getStringExtra(AddActivity.ADD_STUDENT_KEY);
                    Student student = (Student) result.getData()
                            .getSerializableExtra(
                                    AddActivity.ADD_STUDENT_KEY);
                    Toast.makeText(getApplicationContext(),
                            student.toString(),
                            Toast.LENGTH_LONG).show();

                    //populez colectia de studenti
                    students.add(student);
                    //notificare adapter pentru redesenare
                    ArrayAdapter<Student> adapter
                            = (ArrayAdapter<Student>)
                            lvStudents.getAdapter();
                    adapter.notifyDataSetChanged();
                }
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.main_about) {
            //deschidem activitatea about
            Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}