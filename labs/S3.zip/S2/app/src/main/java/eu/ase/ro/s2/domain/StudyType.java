package eu.ase.ro.s2.domain;

public enum StudyType {
    FULL_TIME, DISTANCE
}
