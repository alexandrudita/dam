package com.example.damapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> launcher;

    private FloatingActionButton fabAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
    }

    private void initComponents() {
        //inregistrare lansator
        ActivityResultCallback<ActivityResult> callback = getStudentCallback();
        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                callback);

        fabAdd = findViewById(R.id.main_fab_add);
        fabAdd.setOnClickListener(getAddListener());
    }

    private View.OnClickListener getAddListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aici facem pasul 1 din schema
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                launcher.launch(intent);
            }
        };
    }

    private ActivityResultCallback<ActivityResult> getStudentCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                //este pasul 4 din schema
                if(result.getResultCode() == RESULT_OK && result.getData()!=null){
                    String info = result.getData().getStringExtra(AddActivity.ADD_STUDENT_KEY);
                    Toast.makeText(getApplicationContext(),
                            info,
                            Toast.LENGTH_LONG).show();
                }
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.main_about){
            //deschidem activitatea about
            Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}