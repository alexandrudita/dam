package com.example.damapp.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.damapp.R;
import com.example.damapp.model.Student;

import java.util.List;

public class StudentAdapter extends ArrayAdapter<Student> {

    private Context context;
    private int resource;
    private List<Student> students;
    private LayoutInflater layoutInflater;

    public StudentAdapter(@NonNull Context context,
                          int resource, //R.layout.lv_item
                          @NonNull List<Student> objects,
                          LayoutInflater layoutInflater) {
        super(context, resource, objects);

        this.context = context;
        this.resource = resource;
        this.students = objects;
        this.layoutInflater = layoutInflater;
    }

    @NonNull
    @Override
    public View getView(int position,
                        @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        //sa incarcam in memorie o variabila a template-ului de xml
        // ca sa putem manipula continutul
        View view = layoutInflater.inflate(resource,
                parent, false);

        //definim cele 3 texviewuri
        TextView tvName = view.findViewById(R.id.lv_item_tv_name);
        TextView tvFacultyDetails = view.findViewById(R.id.lv_item_tv_faculty_details);
        TextView tvEnrollmentDate = view.findViewById(R.id.lv_item_tv_enrollment_date);

        //preluam studentul curent
        Student student = students.get(position);

        //populam cele 3 textview
        tvName.setText(student.getName());
        // CSIE la forma de invatamant FULL_TIME
//        String details = student.getFaculty() +
//                " la forma de invatamant "
//                + student.getStudyType().name();
        String details = context.getString(R.string.lv_item_faculty_details_template,
                student.getFaculty(),
                student.getStudyType().name());
        tvFacultyDetails.setText(details);
        tvEnrollmentDate.setText(DateConverter
                .fromDate(student.getEnrollmentDate()));

        return view;
    }
}
