package eu.ase.ro.damapp.firebase;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapp.model.Review;
import eu.ase.ro.damapp.network.Callback;

public class FirebaseService {
    public static final String REVIEW_REFERENCE = "reviews";
    private final DatabaseReference reference;

    public FirebaseService() {
        reference = FirebaseDatabase.getInstance().getReference(REVIEW_REFERENCE);
    }

    public void insert(Review review) {
        if (review == null || (review.getId() != null && !review.getId().trim().isEmpty())) {
            return;
        }
        String id = reference.push().getKey();
        review.setId(id);
        reference.child(review.getId()).setValue(review);
    }

    public void update(Review review) {
        if (review == null || review.getId() == null) {
            return;
        }
        reference.child(review.getId()).setValue(review);
    }

    public void delete(Review review) {
        if (review == null || review.getId() == null || review.getId().trim().isEmpty()) {
            return;
        }
        reference.child(review.getId()).removeValue();
    }

    public void attachDataChangeEventListener(Callback<List<Review>> callback) {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Review> reviews = new ArrayList<>();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Review review = data.getValue(Review.class);
                    if (review != null) {
                        review.setId(data.getKey());
                        reviews.add(review);
                    }
                }

                callback.runResultOnUIThread(reviews);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseService", "Data is not available");
            }
        });
    }

}
