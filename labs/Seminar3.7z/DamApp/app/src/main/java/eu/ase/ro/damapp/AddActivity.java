package eu.ase.ro.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

import eu.ase.ro.damapp.util.DateConverter;
import eu.ase.ro.damapp.util.Student;
import eu.ase.ro.damapp.util.StudyType;

public class AddActivity extends AppCompatActivity {

    public static final String STUDENT_KEY = "studentKey";
    private TextInputEditText tietName;
    private TextInputEditText tietEnrollmentDate;
    private Spinner spnFaculty;
    private RadioGroup rgStudyType;
    private Button btnSave;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //initializare componente vizuale
        initComponents();
        intent = getIntent();
    }

    private void initComponents() {
        tietName = findViewById(R.id.add_tiet_name);
        tietEnrollmentDate = findViewById(R.id.add_tiet_enrollment_date);
        spnFaculty = findViewById(R.id.add_spn_faculty);
        rgStudyType = findViewById(R.id.add_rg_study_type);
        btnSave = findViewById(R.id.add_btn_save);

        btnSave.setOnClickListener(getSaveEvent());
    }

    private View.OnClickListener getSaveEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValid()) {
                    Student student = buildFromComponents();
                    Toast.makeText(getApplicationContext(),
                            student.toString(),
                            Toast.LENGTH_SHORT).show();

                    intent.putExtra(STUDENT_KEY, student);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private Student buildFromComponents() {
        String name = tietName.getText().toString();
        Date enrollmentDate = DateConverter.
                fromString(tietEnrollmentDate.getText().toString());
        String faculty = (String) spnFaculty.getSelectedItem();
        StudyType studyType = StudyType.FULL_TIME;
        if(rgStudyType.getCheckedRadioButtonId()
        ==R.id.add_rb_study_type_distance){
            studyType = StudyType.DISTANCE;
        }

        return  new Student(name, enrollmentDate, studyType,
                faculty);
    }

    private boolean isValid() {
        if (tietName.getText() == null ||
                tietName.getText().toString().trim().length() < 3) {

            Toast.makeText(getApplicationContext(),
                            R.string.add_name_error,
                            Toast.LENGTH_LONG)
                    .show();

            return false;
        }

        if (tietEnrollmentDate.getText() == null
                || DateConverter.fromString(tietEnrollmentDate
                .getText().toString()) == null) {

            Toast.makeText(getApplicationContext(),
                            R.string.add_enrollment_date_error,
                            Toast.LENGTH_LONG)
                    .show();

            return false;
        }

        return true;
    }
}