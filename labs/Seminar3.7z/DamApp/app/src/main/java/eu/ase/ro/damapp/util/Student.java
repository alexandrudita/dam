package eu.ase.ro.damapp.util;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class Student implements Parcelable {

    private String name;
    private Date enrollmentDate;
    private StudyType studyType;
    private String faculty;

    public Student(String name, Date enrollmentDate, StudyType studyType, String faculty) {
        this.name = name;
        this.enrollmentDate = enrollmentDate;
        this.studyType = studyType;
        this.faculty = faculty;
    }

    public Student(Parcel parcel) {
        this.name = parcel.readString();
        this.enrollmentDate = DateConverter.fromString(parcel.readString());
        this.faculty = parcel.readString();
        this.studyType = StudyType.valueOf(parcel.readString());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(Date enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    public StudyType getStudyType() {
        return studyType;
    }

    public void setStudyType(StudyType studyType) {
        this.studyType = studyType;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", enrollmentDate=" + enrollmentDate +
                ", studyType='" + studyType + '\'' +
                ", faculty='" + faculty + '\'' +
                '}';
    }

    public static Creator<Student> CREATOR = new Creator<Student>() {
        @Override
        public Student createFromParcel(Parcel parcel) {
            return new Student(parcel);
        }

        @Override
        public Student[] newArray(int i) {
            return new Student[0];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(DateConverter.fromDate(enrollmentDate));
        parcel.writeString(faculty);
        parcel.writeString(studyType.name());
    }
}
