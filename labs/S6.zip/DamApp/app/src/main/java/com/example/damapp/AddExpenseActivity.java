package com.example.damapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.damapp.model.Expense;
import com.example.damapp.util.DateConverter;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

public class AddExpenseActivity extends AppCompatActivity {

    public static final String EXPENSE_KEY = "expense_key";

    private TextInputEditText tietDescription;
    private TextInputEditText tietDate;
    private TextInputEditText tietAmout;
    private AppCompatSpinner spnCategories;
    private Button btnSave;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);
        initComponents();
        intent = getIntent();
    }

    private void initComponents() {
        tietDescription = findViewById(R.id.add_expense_tiet_description);
        tietDate = findViewById(R.id.add_expense_tiet_date);
        tietAmout = findViewById(R.id.add_expense_tiet_amount);
        spnCategories = findViewById(R.id.add_expense_spn_categories);
        btnSave = findViewById(R.id.add_expense_btn_save);

        btnSave.setOnClickListener(getSaveEvent());
    }

    private View.OnClickListener getSaveEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValid()) {
                    Expense expense = buildFromComponents();
                    intent.putExtra(EXPENSE_KEY, expense);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private Expense buildFromComponents() {
        String description = tietDescription.getText().toString();
        Date date = DateConverter.toDate(tietDate.getText().toString());
        double amount = Double.parseDouble(tietAmout.getText().toString());
        String category = spnCategories.getSelectedItem().toString();

        return new Expense(description, amount, date, category);
    }

    private boolean isValid() {
        if (tietDate.getText() == null || DateConverter.toDate(tietDate.getText().toString()) == null) {
            Toast.makeText(getApplicationContext(), R.string.add_expense_invalid_date, Toast.LENGTH_SHORT).show();
            return false;
        }
        if (tietAmout.getText() == null || tietAmout.getText().toString().trim().isEmpty()
                || Double.parseDouble(tietAmout.getText().toString()) == 0) {
            Toast.makeText(getApplicationContext(), R.string.add_expense_invalid_amount, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

}