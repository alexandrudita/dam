package com.example.damapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.damapp.R;
import com.example.damapp.model.Expense;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    public static final String EXPENSES_KEY = "EXPENSES_KEY";

    private List<Expense> expenses;
    private ListView lvExpenses;

    public HomeFragment() {
        // Required empty public constructor
    }


    public static HomeFragment newInstance(
            List<Expense> expenses) {

        HomeFragment fragment = new HomeFragment();

        Bundle args = new Bundle();

        args.putParcelableArrayList(EXPENSES_KEY,
                (ArrayList<Expense>) expenses);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //locul in care citesc datele din Bundle
            expenses = getArguments()
                    .getParcelableArrayList(EXPENSES_KEY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        lvExpenses = view.findViewById(R.id.home_lv_expenses);
        ArrayAdapter<Expense> adapter = new ArrayAdapter<>(
                getContext().getApplicationContext(),
                android.R.layout.simple_list_item_1,
                expenses
        );
        lvExpenses.setAdapter(adapter);
        return view;
    }

    public void notifyAdapter() {
        ArrayAdapter<Expense> adapter =
                (ArrayAdapter<Expense>) lvExpenses.getAdapter();
        adapter.notifyDataSetChanged();
    }
}