package eu.ase.ro.damapp.network;

public interface Callback<R> {

    void runResultOnUiThread(R result);
}
