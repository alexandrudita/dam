package eu.ase.ro.damapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eu.ase.ro.damapp.util.BankAccount;
import eu.ase.ro.damapp.util.ChartView;

public class ChartActivity extends AppCompatActivity {

    public static final String ACCOUNTS_KEY = "accounts";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        List<BankAccount> accounts = (List<BankAccount>) getIntent().getSerializableExtra(ACCOUNTS_KEY);
        Map<String, Integer> source = calculateChartSource(accounts);
        setContentView(new ChartView(getApplicationContext(), source));
    }

    private Map<String, Integer> calculateChartSource(List<BankAccount> accounts) {
        if (accounts == null || accounts.isEmpty()) {
            return new HashMap<>();
        }
        Map<String, Integer> source = new HashMap<>();
        for (BankAccount account : accounts) {
            String key = account.getBankName();
            if (source.containsKey(key)) {
                Integer currentValue = source.get(key);
                source.put(key, currentValue + 1);
            } else {
                source.put(key, 1);
            }
        }
        return source;
    }
}