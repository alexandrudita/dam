package eu.ase.ro.damapp.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.Map;

import eu.ase.ro.damapp.R;

public class ChartView extends View {

    private final Context context;
    private final Map<String, Integer> source;
    private final Paint paint;

    public ChartView(Context context, Map<String, Integer> source) {
        super(context);
        this.context = context;
        this.source = source;
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (source == null || source.isEmpty()) {
            return;
        }

        //valoarea unei bare
        float widthBar = (float) getWidth() / source.size();
        //valoarea maxima
        int maxValue = calculateMax();
        //trasare grafic
        int currentBarPosition = 0;
        for (String label : source.keySet()) {
            //valoare curenta
            int value = source.get(label);
            paint.setColor(generateColor(currentBarPosition));
            //trasare bara
            float x1 = currentBarPosition * widthBar;
            float y1 = (1 - (float) value / maxValue) * getHeight();
            float x2 = x1 + widthBar;
            float y2 = getHeight();
            canvas.drawRect(x1, y1, x2, y2, paint);
            //trasare legenda
            paint.setColor(Color.BLACK);
            paint.setTextSize((float) (0.25 * widthBar));
            float x = (float) ((currentBarPosition + 0.5) * widthBar);
            float y = (float) (0.95 * getHeight());
            canvas.rotate(270, x, y);
            canvas.drawText(context.getString(R.string.chart_legend_template, label, value), x, y, paint);
            canvas.rotate(-270, x, y);
            //trecem la urmatoarea bara
            currentBarPosition++;
        }

    }

    private int generateColor(int currentBarPosition) {
        return currentBarPosition % 2 == 0 ? Color.LTGRAY : Color.CYAN;
    }

    private int calculateMax() {
        int max = 0;
        for (Integer value : source.values()) {
            if (max < value) {
                max = value;
            }
        }
        return max;
    }
}
