package eu.ase.ro.damapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import eu.ase.ro.damapp.network.AsyncTaskRunner;
import eu.ase.ro.damapp.network.Callback;
import eu.ase.ro.damapp.network.HttpManager;
import eu.ase.ro.damapp.util.BankAccount;
import eu.ase.ro.damapp.util.BankAccountAdapter;
import eu.ase.ro.damapp.util.BankAccountJsonParser;

public class MainActivity extends AppCompatActivity {

    private final static String BANK_ACCOUNT_URL = "https://api.npoint.io/2dffffc22b52e9fecceb";

    private FloatingActionButton fabAdd;
    private ListView lvAccounts;

    private ActivityResultLauncher<Intent> addLauncher;

    private List<BankAccount> bankAccounts = new ArrayList<>();
    private AsyncTaskRunner asyncTaskRunner = new AsyncTaskRunner();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
        addLauncher = registerAddLauncher();
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 3, 2022, "BRD"));

        loadBankAccountsFromHttp();
    }

    private void loadBankAccountsFromHttp() {
        Callable<String> asyncOperation = new HttpManager(BANK_ACCOUNT_URL);
        Callback<String> mainThreadOperation = mainThreadOperationHttpJson();
        asyncTaskRunner.executeAsync(asyncOperation, mainThreadOperation);
    }

    private Callback<String> mainThreadOperationHttpJson() {
        return new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                bankAccounts.clear();
                bankAccounts.addAll(BankAccountJsonParser.fromJson(result));
                notifyAdapter();
            }
        };
    }

    private void initComponents() {
        fabAdd = findViewById(R.id.main_fab_add);
        lvAccounts = findViewById(R.id.main_lv_bank_accounts);

        fabAdd.setOnClickListener(getAddEvent());
        BankAccountAdapter adapter = new BankAccountAdapter(getApplicationContext(), R.layout.lv_row_item, bankAccounts, getLayoutInflater());
        lvAccounts.setAdapter(adapter);
    }

    private View.OnClickListener getAddEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                addLauncher.launch(intent);
            }
        };
    }

    private ActivityResultLauncher<Intent> registerAddLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddBankAccountResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddBankAccountResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    BankAccount account = (BankAccount) result.getData().getSerializableExtra(AddActivity.BANK_ACCOUNT_KEY);
                    bankAccounts.add(account);
                    notifyAdapter();
                }
            }
        };
    }

    private void notifyAdapter() {
        BankAccountAdapter adapter = (BankAccountAdapter) lvAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.main_note) {
            Intent intent = new Intent(getApplicationContext(), NoteActivity.class);
            startActivity(intent);
        } else if(item.getItemId() == R.id.main_raport){
            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                    .setTitle(R.string.dialog_title)
                    .setMessage(R.string.dialog_message)
                    .setPositiveButton(R.string.dialog_yes_label, getPositiveDialogEvent())
                    .setNegativeButton(R.string.dialog_no_label, getNegativeDialogEvent())
                    .create();
            dialog.show();
        }
        return super.onOptionsItemSelected(item);
    }

    private DialogInterface.OnClickListener getNegativeDialogEvent() {
        return new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), R.string.no_generation_message, Toast.LENGTH_SHORT).show();
            }
        };
    }

    private DialogInterface.OnClickListener getPositiveDialogEvent() {
        return new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(getApplicationContext(), ChartActivity.class);
                intent.putExtra(ChartActivity.ACCOUNTS_KEY, (Serializable) bankAccounts);
                startActivity(intent);
            }
        };
    }
}