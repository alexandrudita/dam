package eu.ase.ro.seminar7;

import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar7.util.BankAccount;
import eu.ase.ro.seminar7.util.BankAccountAdapter;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView lvBankAccounts;
    private List<BankAccount> bankAccounts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        bankAccounts.add(new BankAccount("FAKE 1",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("FAKE2",
                1234567890123456L, 3, 2022, "BRD"));
    }

    private void initComponents() {
        lvBankAccounts = findViewById(R.id.main_lv_bank_accounts);
        addBankAccountAdapter();
    }

    private void addBankAccountAdapter() {
        BankAccountAdapter adapter = new BankAccountAdapter(getApplicationContext(), R.layout.lv_row_view, bankAccounts, getLayoutInflater());
        lvBankAccounts.setAdapter(adapter);
    }

    private void notifyAdapter(){
        BankAccountAdapter adapter = (BankAccountAdapter) lvBankAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }
}