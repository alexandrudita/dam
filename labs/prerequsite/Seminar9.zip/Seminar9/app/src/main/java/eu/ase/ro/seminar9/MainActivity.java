package eu.ase.ro.seminar9;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvUpdatedAt;
    private TextInputEditText tietNotes;
    private FloatingActionButton fabSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
    }

    private void initComponents() {
        tvUpdatedAt = findViewById(R.id.main_tv_updated_at);
        tietNotes = findViewById(R.id.main_tiet_notes);
        fabSave = findViewById(R.id.main_fab_save);
        fabSave.setOnClickListener(getSaveClickEvent());
    }

    private View.OnClickListener getSaveClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), R.string.save_pushed_message, Toast.LENGTH_SHORT).show();
            }
        };
    }
}