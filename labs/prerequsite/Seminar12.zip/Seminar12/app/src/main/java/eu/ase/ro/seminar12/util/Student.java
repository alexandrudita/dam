package eu.ase.ro.seminar12.util;

import java.io.Serializable;

import androidx.annotation.NonNull;

public class Student implements Serializable {

    private String id;
    private String name;
    private String faculty;

    public Student() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    @NonNull
    @Override
    public String toString() {
        return "Student: " + name + " - " + faculty;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
