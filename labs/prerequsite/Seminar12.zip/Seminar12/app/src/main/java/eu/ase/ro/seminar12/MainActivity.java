package eu.ase.ro.seminar12;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar12.firebase.FirebaseService;
import eu.ase.ro.seminar12.util.Callback;
import eu.ase.ro.seminar12.util.Student;
import eu.ase.ro.seminar12.util.StudentAdapter;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText tietName;
    private Spinner spnFaculty;
    private Button btnClearFields;
    private FloatingActionButton fabDelete;
    private FloatingActionButton fabSave;
    private FloatingActionButton fabChart;
    private ListView lvStudents;

    private List<Student> students = new ArrayList<>();

    private int selectedStudentIndex = -1;

    private FirebaseService firebaseService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        firebaseService = FirebaseService.getInstance();
        firebaseService.attachDataChangeEventListener(dataChangeCallback());
    }

    private Callback<List<Student>> dataChangeCallback() {
        return new Callback<List<Student>>() {
            @Override
            public void runResultOnUiThread(List<Student> results) {
                if (results != null) {
                    //code apelat din FirebaseService in metoda onDataChange
                    students.clear();
                    students.addAll(results);
                    notifyListViewStudentAdapter();
                    clearFields();
                }
            }
        };
    }

    private void initComponents() {
        tietName = findViewById(R.id.main_tiet_name);
        spnFaculty = findViewById(R.id.main_spn_faculties);
        btnClearFields = findViewById(R.id.main_btn_clear_fields);
        fabDelete = findViewById(R.id.main_fab_delete);
        fabSave = findViewById(R.id.main_fab_save);
        fabChart = findViewById(R.id.main_fab_chart);
        lvStudents = findViewById(R.id.main_lv_students);
        addSpinnerFacultiesAdapter();
        addListViewStudentsAdapter();
        btnClearFields.setOnClickListener(getClearFieldsClickEvent());
        fabSave.setOnClickListener(getSaveStudentClickEvent());
        fabDelete.setOnClickListener(getDeleteStudentClickEvent());
        lvStudents.setOnItemClickListener(getSelectStudentClickEvent());
        fabChart.setOnClickListener(getChartClickEvent());
    }

    private View.OnClickListener getChartClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO add chart generation 
            }
        };
    }

    private View.OnClickListener getClearFieldsClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        };
    }

    private View.OnClickListener getSaveStudentClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    if (selectedStudentIndex == -1) {
                        Student student = updateStudentFromView(null);
                        firebaseService.insert(student);
                    } else {
                        Student student = updateStudentFromView(students.get(selectedStudentIndex).getId());
                        firebaseService.update(student);
                    }
                }
            }
        };
    }

    private View.OnClickListener getDeleteStudentClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedStudentIndex != -1) {
                    firebaseService.delete(students.get(selectedStudentIndex));
                }
            }
        };
    }

    private AdapterView.OnItemClickListener getSelectStudentClickEvent() {
        return new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedStudentIndex = position;
                Student student = students.get(position);
                tietName.setText(student.getName());
                selectFaculty(student.getFaculty());
            }
        };
    }

    private boolean isValid() {
        if (tietName.getText() == null || tietName.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.main_invalid_name_error,
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private Student updateStudentFromView(String id) {
        Student student = new Student();
        student.setId(id);
        student.setName(tietName.getText().toString());
        student.setFaculty((String) spnFaculty.getSelectedItem());
        return student;
    }

    private void addSpinnerFacultiesAdapter() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.faculties_options, android.R.layout.simple_spinner_dropdown_item);
        spnFaculty.setAdapter(adapter);
    }

    private void addListViewStudentsAdapter() {
        StudentAdapter adapter = new StudentAdapter(getApplicationContext(), R.layout.lv_row_view,
                students, getLayoutInflater());
        lvStudents.setAdapter(adapter);
    }

    private void notifyListViewStudentAdapter() {
        StudentAdapter adapter = (StudentAdapter) lvStudents.getAdapter();
        adapter.notifyDataSetChanged();
    }

    private void selectFaculty(String faculty) {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) spnFaculty.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            if (adapter.getItem(i).equals(faculty)) {
                spnFaculty.setSelection(i);
                break;
            }
        }
    }

    private void clearFields() {
        tietName.setText(null);
        spnFaculty.setSelection(0);
        selectedStudentIndex = -1;
    }

}