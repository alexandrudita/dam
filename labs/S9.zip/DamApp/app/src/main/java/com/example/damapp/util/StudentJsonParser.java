package com.example.damapp.util;

import androidx.annotation.NonNull;

import com.example.damapp.model.Student;
import com.example.damapp.model.StudyType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class StudentJsonParser {

    public static final String NAME = "name";
    public static final String FACULTY = "faculty";
    public static final String STUDY_TYPE = "studyType";
    public static final String ENROLLMENT_DATE = "enrollmentDate";

    public static List<Student> fromJson(String json) {
        try {
            JSONArray array = new JSONArray(json);
            return getStudents(array);
        } catch (JSONException e) {
            return new ArrayList<>();
        }
    }

    @NonNull
    private static List<Student> getStudents(JSONArray array) throws JSONException {
        List<Student> results = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject object = array.getJSONObject(i);
            Student student = getStudent(object);
            results.add(student);
        }

        return results;
    }

    @NonNull
    private static Student getStudent(JSONObject object) throws JSONException {
        String name = object.getString(NAME);
        String faculty = object.getString(FACULTY);
        StudyType studyType = StudyType.valueOf(object.getString(STUDY_TYPE));
        Date enrollmentDate = DateConverter.toDate(object.getString(ENROLLMENT_DATE));

        return new Student(name, enrollmentDate, faculty, studyType);
    }
}
