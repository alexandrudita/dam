package eu.ase.ro.damapproom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import eu.ase.ro.damapproom.util.Expense;

@Dao
public interface ExpenseDao {
    @Insert
    long insert(Expense expense);//rezultatul este id-ul inregistrarii. daca este <0 reprezinta eroare

    @Query("select * from expenses")
    List<Expense> getAll();

    @Update
    int update(Expense expense);

    @Delete
    int delete(Expense expense);
}
