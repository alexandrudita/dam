package eu.ase.ro.damapproom.database;

import android.content.Context;

import java.util.List;
import java.util.concurrent.Callable;

import eu.ase.ro.damapproom.async.AsyncTaskRunner;
import eu.ase.ro.damapproom.async.Callback;
import eu.ase.ro.damapproom.util.Expense;

public class ExpenseService {

    private final AsyncTaskRunner taskRunner = new AsyncTaskRunner();
    private final ExpenseDao expenseDao;

    public ExpenseService(Context context) {
        expenseDao = DatabaseManager.getInstance(context).getExpenseDao();
    }

    public void insert(Expense expense, Callback<Expense> insertCallback) {
        Callable<Expense> callable = new Callable<Expense>() {
            @Override
            public Expense call() {
                //sunt pe un thread paralel cu cel principal
                if (expense.getId() > 0) {
                    return null;
                }
                long id = expenseDao.insert(expense);
                if (id < 0) {
                    return null;
                }
                expense.setId(id);
                return expense;
            }
        };

        //executam callable pe celalt thread
        taskRunner.executeAsync(callable, insertCallback);
    }

    public void getAll(Callback<List<Expense>> getAllCallback) {
        Callable<List<Expense>> callable = new Callable<List<Expense>>() {
            @Override
            public List<Expense> call() {
                return expenseDao.getAll();
            }
        };
        taskRunner.executeAsync(callable, getAllCallback);
    }

    public void update(Expense expense, Callback<Expense> updateCallback) {
        Callable<Expense> callable = new Callable<Expense>() {
            @Override
            public Expense call() {
                if (expense == null || expense.getId() <= 0) {
                    return null;
                }
                int count = expenseDao.update(expense);
                if (count <= 0) {
                    return null;
                }
                return expense;
            }
        };
        taskRunner.executeAsync(callable, updateCallback);
    }

    public void delete(Expense expense, Callback<Boolean> deleteCallback) {
        Callable<Boolean> callable = new Callable<Boolean>() {
            @Override
            public Boolean call() {
                if (expense == null || expense.getId() <= 0) {
                    return false;
                }
                int count = expenseDao.delete(expense);
                return count > 0;
            }
        };
        taskRunner.executeAsync(callable, deleteCallback);
    }
}
