package eu.ase.ro.damapproom.database;

import android.content.Context;

import java.util.List;
import java.util.concurrent.Callable;

import eu.ase.ro.damapproom.async.AsyncTaskRunner;
import eu.ase.ro.damapproom.async.Callback;
import eu.ase.ro.damapproom.util.Expense;

public class ExpenseService {
    private final AsyncTaskRunner asyncTaskRunner;
    private final ExpenseDao expenseDao;

    public ExpenseService(Context context) {
        asyncTaskRunner = new AsyncTaskRunner();
        expenseDao = DatabaseManager.getInstance(context).getExpenseDao();
    }

    public void insert(Expense expense, Callback<Expense> insertActivityThread) {
        Callable<Expense> insertOperation = new Callable<Expense>() {
            @Override
            public Expense call() throws Exception {
                if (expense == null || expense.getId() > 0) {
                    return null;
                }
                //aici ne aflam pe un alt thread...
                long id = expenseDao.insert(expense);
                if (id < 0) {
                    return null;
                }
                expense.setId(id);
                return expense;
            }
        };
        asyncTaskRunner.executeAsync(insertOperation, insertActivityThread);
    }

    public void getAll(Callback<List<Expense>> getAllActivityThread) {
        Callable<List<Expense>> getAllOperation = new Callable<List<Expense>>() {
            @Override
            public List<Expense> call() throws Exception {
                //ne aflam pe un alt thread.
                //ma conectez la baza de date
                return expenseDao.getAll();
            }
        };

        asyncTaskRunner.executeAsync(getAllOperation, getAllActivityThread);
    }

    public void update(Expense expense, Callback<Expense> updateActivityThread) {
        Callable<Expense> updateOperation = new Callable<Expense>() {
            @Override
            public Expense call() throws Exception {
                if (expense == null || expense.getId() <= 0) {
                    return null;
                }
                int count = expenseDao.update(expense);
                if (count < 1) {
                    return null;
                }
                return expense;
            }
        };

        asyncTaskRunner.executeAsync(updateOperation, updateActivityThread);
    }

    public void delete(Expense expense, Callback<Boolean> deleteActivityThread) {
        Callable<Boolean> deleteOperation = new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                int count = expenseDao.delete(expense);
                return count >= 1;
            }
        };

        asyncTaskRunner.executeAsync(deleteOperation, deleteActivityThread);
    }
}
