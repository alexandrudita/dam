package eu.ase.ro.damapproom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import eu.ase.ro.damapproom.util.Expense;

@Dao
public interface ExpenseDao {

    @Insert
    long insert(Expense expense); //id- daca totul este ok; sau -1 daca au fost probleme la insert
    @Query("select * from expenses")
    List<Expense> getAll();
    @Update
    int update(Expense expense); // reprezinta numarul de inregistrari afectate
    @Delete
    int delete(Expense expense);

}
