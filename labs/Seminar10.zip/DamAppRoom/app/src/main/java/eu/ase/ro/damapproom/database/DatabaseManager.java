package eu.ase.ro.damapproom.database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import eu.ase.ro.damapproom.util.DateConverter;
import eu.ase.ro.damapproom.util.Expense;

@Database(entities = {Expense.class}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class DatabaseManager extends RoomDatabase {

    //Singleton - de citit acasa - o sa avem intrebari data viitoare
    private static DatabaseManager databaseManager;

    public static DatabaseManager getInstance(Context context) {

        if (databaseManager == null) {
            //de citi synchronized pentru data viitoare.
            synchronized (DatabaseManager.class){
                if(databaseManager == null){
                    databaseManager = Room.databaseBuilder(context, DatabaseManager.class, "dam_db")
                            .fallbackToDestructiveMigration()
                            //.allowMainThreadQueries() //- nu folosim asa ceva. doar pentru teste
                            .build();
                }
            }
        }
        return databaseManager;
    }

    public abstract ExpenseDao getExpenseDao();
}
