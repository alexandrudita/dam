package eu.ase.ro.seminar2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class AddActivity extends AppCompatActivity {

    private Spinner spnFaculty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //initializare componente vizuale
        spnFaculty = findViewById(R.id.spn_add_faculty);
        //creare adapter cu vector constant static in strings.xml
        ArrayAdapter<CharSequence> adapter = ArrayAdapter
                .createFromResource(getApplicationContext(),
                        R.array.add_faculty_values,
                        android.R.layout.simple_spinner_dropdown_item);
        //spinner setam adapterul
        spnFaculty.setAdapter(adapter);
    }
}