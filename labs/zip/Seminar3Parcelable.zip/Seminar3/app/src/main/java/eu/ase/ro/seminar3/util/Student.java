package eu.ase.ro.seminar3.util;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

import androidx.annotation.NonNull;

import static eu.ase.ro.seminar3.util.StudyType.FULL_TIME;

public class Student implements Parcelable {

    private String name;
    private int age;
    private Date enrollmentDate;
    private StudyType studyType;
    private String faculty;

    public Student(String name, int age, Date enrollmentDate, StudyType studyType, String faculty) {
        this.name = name;
        this.age = age;
        this.enrollmentDate = enrollmentDate;
        this.studyType = studyType;
        this.faculty = faculty;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Date getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(Date enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    public StudyType getStudyType() {
        return studyType;
    }

    public void setStudyType(StudyType studyType) {
        this.studyType = studyType;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    @NonNull
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", enrollmentDate=" + enrollmentDate +
                ", studyType=" + studyType +
                ", faculty='" + faculty + '\'' +
                '}';
    }

    private Student(Parcel source) {
        //ordinea de scriere in fisier trebuie respectata si la citire
        name = source.readString();
        age = source.readInt();
        enrollmentDate = DateConverter.fromString(source.readString());
        studyType = FULL_TIME.name().equals(source.readString()) ? FULL_TIME : StudyType.DISTANCE;
        faculty = source.readString();
    }

    //Creatorul este public deoarece acesta trebuie sa fie invocat de pachetul
    // android care se afla in exteriorul clasei noastre
    //Este static deoarece dorim sa obtinem o instanta Java pe baza fisierului parcel,
    // ceea ce inseamna ca nu poate depinde de vreo instanta ci de clasa
    // (cititi ce inseamna o variabila static - POO si Java)
    public static Creator<Student> CREATOR = new Creator<Student>() {
        @Override
        public Student createFromParcel(Parcel source) {
            return new Student(source);
        }

        @Override
        public Student[] newArray(int size) {
            return new Student[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        //ordinea de scriere in fisier trebuie respectata si la citire
        dest.writeString(name);
        dest.writeInt(age);
        dest.writeString(DateConverter.fromDate(enrollmentDate));
        dest.writeString(studyType.name());
        dest.writeString(faculty);
    }
}
