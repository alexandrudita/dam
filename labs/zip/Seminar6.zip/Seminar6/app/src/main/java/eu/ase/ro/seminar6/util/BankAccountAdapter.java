package eu.ase.ro.seminar6.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import eu.ase.ro.seminar6.R;

public class BankAccountAdapter extends ArrayAdapter<BankAccount> {

    private Context context;
    private int resource;
    private List<BankAccount> accounts;
    private LayoutInflater inflater;

    public BankAccountAdapter(@NonNull Context context, int resource, @NonNull List<BankAccount> objects,
                              LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.accounts = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        BankAccount account = accounts.get(position);
        if (account == null) {
            return view;
        }
        addBankName(view, account.getBankName());
        addCardHolderName(view, account.getCardHolderName());
        addCardNumber(view, account.getCardNumber());
        addExpirationTime(view, account.getExpirationMonth(), account.getExpirationYear());
        return view;
    }

    private void addExpirationTime(View view, int expirationMonth, int expirationYear) {
        TextView textView = view.findViewById(R.id.row_tv_expiration_time);
        String value = context.getString(R.string.row_expiration_time_template, expirationMonth, expirationYear);
        populateTextViewContent(textView, value);
    }

    private void addCardNumber(View view, long cardNumber) {
        TextView textView = view.findViewById(R.id.row_tv_card_number);
        populateTextViewContent(textView, String.valueOf(cardNumber));
    }

    private void addCardHolderName(View view, String cardHolderName) {
        TextView textView = view.findViewById(R.id.row_tv_card_holder_name);
        populateTextViewContent(textView, cardHolderName);
    }

    private void addBankName(View view, String bankName) {
        TextView textView = view.findViewById(R.id.row_tv_bank_name);
        populateTextViewContent(textView, bankName);
    }

    private void populateTextViewContent(TextView textView, String value) {
        if (value != null && !value.trim().isEmpty()) {
            textView.setText(value);
        } else {
            textView.setText(R.string.row_bank_account_default_value);
        }
    }
}
