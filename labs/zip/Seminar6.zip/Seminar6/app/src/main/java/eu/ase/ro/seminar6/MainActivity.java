package eu.ase.ro.seminar6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar6.util.BankAccount;
import eu.ase.ro.seminar6.util.BankAccountAdapter;

public class MainActivity extends AppCompatActivity {

    private ListView lvBankAccounts;
    private FloatingActionButton fabAddBankAccount;
    private List<BankAccount> bankAccounts = new ArrayList<>();
    private ActivityResultLauncher<Intent> addBankAccountLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 3, 2022, "BRD"));
    }

    private void initComponents() {
        lvBankAccounts = findViewById(R.id.main_lv_bank_accounts);
        fabAddBankAccount = findViewById(R.id.main_fab_add_bank_account);

        addBankAccountAdapter();
        fabAddBankAccount.setOnClickListener(getAddBankAccountClickListener());
        addBankAccountLauncher = getAddBankAccountLauncher();
    }

    private void addBankAccountAdapter() {
//        ArrayAdapter<BankAccount> adapter = new ArrayAdapter<>(getApplicationContext(),
//                android.R.layout.simple_list_item_1, bankAccounts);
        BankAccountAdapter adapter = new BankAccountAdapter(getApplicationContext(),
                R.layout.lv_row_view, bankAccounts, getLayoutInflater());
        lvBankAccounts.setAdapter(adapter);
    }

    private View.OnClickListener getAddBankAccountClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddBankAccountActivity.class);
                addBankAccountLauncher.launch(intent);
            }
        };
    }

    private ActivityResultLauncher<Intent> getAddBankAccountLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddBankAccountActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddBankAccountActivityResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    BankAccount bankAccount = (BankAccount) result.getData().getSerializableExtra(AddBankAccountActivity.BANK_ACCOUNT_KEY);
                    if (bankAccount != null) {
                        Toast.makeText(getApplicationContext(), R.string.main_new_bank_account_added_message, Toast.LENGTH_SHORT).show();
                        bankAccounts.add(bankAccount);
                        notifyAdapter();
                    }
                }
            }
        };
    }

    private void notifyAdapter() {
        ArrayAdapter adapter = (ArrayAdapter) lvBankAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }
}