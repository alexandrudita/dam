package eu.ase.ro.seminar7;

import android.os.Bundle;
import android.os.Handler;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar7.network.HttpManager;
import eu.ase.ro.seminar7.util.BankAccount;
import eu.ase.ro.seminar7.util.BankAccountAdapter;
import eu.ase.ro.seminar7.util.BankAccountJsonParser;

public class MainActivity extends AppCompatActivity {

    private final static String BANK_ACCOUNT_URL = "https://jsonkeeper.com/b/PE13";
    private ListView lvBankAccounts;
    private List<BankAccount> bankAccounts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        bankAccounts.add(new BankAccount("FAKE 1",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("FAKE2",
                1234567890123456L, 3, 2022, "BRD"));
        loadBankAccountsFromHttp();
    }

    private void initComponents() {
        lvBankAccounts = findViewById(R.id.main_lv_bank_accounts);
        addBankAccountAdapter();
    }

    private void addBankAccountAdapter() {
        BankAccountAdapter adapter = new BankAccountAdapter(getApplicationContext(), R.layout.lv_row_view, bankAccounts, getLayoutInflater());
        lvBankAccounts.setAdapter(adapter);
    }

    private void loadBankAccountsFromHttp() {
        Thread thread = new Thread() {
            @Override
            public void run() {
                //procesare paralela cu firul principal din activtate
                HttpManager manager = new HttpManager(BANK_ACCOUNT_URL);
                String result = manager.process();
                new Handler(getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        mainThreadGetBankAccountsFromHttpCallback(result);
                    }
                });
            }
        };
        thread.start();
    }

    private void mainThreadGetBankAccountsFromHttpCallback(String result) {
        Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
        //apelam parsatorul de json, iar rezultatul obtinut il adaugam in lista de obiecte BankAccount
        //existenta la nivelul activitati
        bankAccounts.addAll(BankAccountJsonParser.fromJson(result));
        //avand in vedere ca lista de obiecte este modificata la linia de mai sus,
        // este necesar sa notificam adapterul de acest lucru astfel incat obiectele noi
        //sa fie incarcate in ListView
        notifyAdapter();
    }

    private void notifyAdapter() {
        BankAccountAdapter adapter = (BankAccountAdapter) lvBankAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }
}