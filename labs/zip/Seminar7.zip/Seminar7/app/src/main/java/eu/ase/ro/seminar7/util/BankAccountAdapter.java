package eu.ase.ro.seminar7.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import eu.ase.ro.seminar7.R;


public class BankAccountAdapter extends ArrayAdapter<BankAccount> {

    private Context context;
    private int resource;
    private List<BankAccount> bankAccounts;
    private LayoutInflater inflater;

    public BankAccountAdapter(@NonNull Context context, int resource, @NonNull List<BankAccount> objects,
                              LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.bankAccounts = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View cview, @NonNull ViewGroup parent) {
        @SuppressLint("ViewHolder") View view = inflater.inflate(resource, parent, false);
        BankAccount account = bankAccounts.get(position);
        if (account == null) {
            return view;
        }
        addCardHolderName(view, account.getCardHolderName());
        addBankName(view, account.getBankName());
        addCardNumber(view, account.getCardNumber());
        addExpirationPeriod(view, account.getExpirationMonth(), account.getExpirationYear());
        return view;
    }

    private void addCardHolderName(View view, String cardHolderName) {
        TextView textView = view.findViewById(R.id.row_tv_card_holder_name);
        populateTextViewContent(textView, cardHolderName);
    }

    private void addBankName(View view, String bankName) {
        TextView textView = view.findViewById(R.id.row_tv_bank_name);
        populateTextViewContent(textView, bankName);
    }

    private void addCardNumber(View view, long cardNumber) {
        TextView textView = view.findViewById(R.id.row_tv_card_number);
        populateTextViewContent(textView, String.valueOf(cardNumber));
    }

    private void addExpirationPeriod(View view, int expirationMonth, int expirationYear) {
        TextView textView = view.findViewById(R.id.row_tv_expiration_time);
        String value = context.getString(R.string.expiration_time_template, expirationMonth, expirationYear);
        populateTextViewContent(textView, value);
    }

    private void populateTextViewContent(TextView textView, String value) {
        if (value != null && !value.trim().isEmpty()) {
            textView.setText(value);
        } else {
            textView.setText(R.string.default_row_view_value);
        }
    }
}
