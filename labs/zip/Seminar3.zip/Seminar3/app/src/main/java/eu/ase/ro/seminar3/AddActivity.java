package eu.ase.ro.seminar3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar3.util.DateConverter;
import eu.ase.ro.seminar3.util.Student;
import eu.ase.ro.seminar3.util.StudyType;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_STUDENT_KEY = "ADD_STUDENT_KEY";
    private TextInputEditText tietName;
    private TextInputEditText tietAge;
    private TextInputEditText tietEnrollmentDate;
    private Spinner spnFaculty;
    private RadioGroup rgStudyType;
    private Button btnSave;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        //initializare componente vizuale
        initComponents();
        //preluare intent
        intent = getIntent();
    }

    private void initComponents() {
        tietName = findViewById(R.id.tiet_add_name);
        tietAge = findViewById(R.id.tiet_add_age);
        tietEnrollmentDate = findViewById(R.id.tiet_add_enrollment_date);
        rgStudyType = findViewById(R.id.rg_add_study_type);
        btnSave = findViewById(R.id.btn_add_save);
        spnFaculty = findViewById(R.id.spn_add_faculty);
        addSpinnerFacultyAdapter();
        btnSave.setOnClickListener(getSaveStudentClickListener());
    }

    private View.OnClickListener getSaveStudentClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //validare
                if (isValid()) {
                    //preluare date de la tastatura
                    Student student = buildStudentFromComponents();
                    //logare informatie de tip student
                    Log.i("AddActivity", student.toString());
                    //adaug studentul pe intentul primit
                    intent.putExtra(ADD_STUDENT_KEY, student);
                    //trimitem intentul catre MainActivity
                    setResult(RESULT_OK, intent);
                    //distrugere activitate secundara + fortare apel callback din MainActivity
                    finish();
                }
            }
        };
    }

    private Student buildStudentFromComponents() {
        String name = tietName.getText().toString();
        int age = Integer.parseInt(tietAge.getText().toString().trim());
        Date enrollmentDate = DateConverter.fromString(tietEnrollmentDate.getText().toString().trim());
        String faculty = spnFaculty.getSelectedItem().toString();
        StudyType studyType = StudyType.FULL_TIME;
        if (rgStudyType.getCheckedRadioButtonId() == R.id.rb_add_study_type_distance) {
            studyType = StudyType.DISTANCE;
        }
        return new Student(name, age, enrollmentDate, studyType, faculty);
    }

    private boolean isValid() {
        if (tietName.getText() == null || tietName.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.add_name_error_message,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (tietAge.getText() == null || tietAge.getText().toString().trim().isEmpty()
                || Integer.parseInt(tietAge.getText().toString().trim()) < 18
                || Integer.parseInt(tietAge.getText().toString().trim()) > 70) {
            Toast.makeText(getApplicationContext(),
                    R.string.add_age_error_message,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }

        if (tietEnrollmentDate.getText() == null
                || DateConverter.fromString(tietEnrollmentDate.getText().toString().trim()) == null) {
            Toast.makeText(getApplicationContext(),
                    R.string.add_enrollment_date_error_message,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }

        return true;
    }

    private void addSpinnerFacultyAdapter() {
        //creare adapter cu vector constant static in strings.xml
        ArrayAdapter<CharSequence> adapter = ArrayAdapter
                .createFromResource(getApplicationContext(),
                        R.array.add_faculty_values,
                        android.R.layout.simple_spinner_dropdown_item);
        //spinner setam adapterul
        spnFaculty.setAdapter(adapter);
    }
}