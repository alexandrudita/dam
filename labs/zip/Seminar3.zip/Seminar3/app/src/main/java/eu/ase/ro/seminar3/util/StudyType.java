package eu.ase.ro.seminar3.util;

public enum StudyType {
    FULL_TIME, DISTANCE;
}
