package eu.ase.ro.seminar9;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar9.util.DateConverter;

public class MainActivity extends AppCompatActivity {

    public static final String NOTES = "NOTES";
    public static final String UPDATED_AT = "UPDATED_AT";
    public static final String NO_CHARACTERS = "NO_CHARACTERS";
    public static final String NOTES_SHARED_PREF = "notesSharedPref";
    private TextView tvUpdatedAt;
    private TextView tvNoCharacters;
    private TextInputEditText tietNotes;
    private FloatingActionButton fabSave;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        loadNotesSharedPreference();
    }

    private void initComponents() {
        tvUpdatedAt = findViewById(R.id.main_tv_updated_at);
        tvNoCharacters = findViewById(R.id.main_tv_no_characters);
        tietNotes = findViewById(R.id.main_tiet_notes);
        fabSave = findViewById(R.id.main_fab_save);
        fabSave.setOnClickListener(getSaveClickEvent());

        //initializare fisier de preferinte
        preferences = getSharedPreferences(NOTES_SHARED_PREF, MODE_PRIVATE);
    }

    private View.OnClickListener getSaveClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    Toast.makeText(getApplicationContext(), R.string.save_pushed_message, Toast.LENGTH_SHORT).show();
                    saveNotesSharedPreference();
                }
            }
        };
    }

    private void saveNotesSharedPreference() {
        //preluarea informatiilor din componentele vizuale
        String notes = tietNotes.getText() != null ? tietNotes.getText().toString() : "";
        String updatedAt = DateConverter.fromDate(new Date());
        int noCharacters = notes.length();

        //salvarea in fisierul de preferinta
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(NOTES, notes);
        editor.putString(UPDATED_AT, updatedAt);
        editor.putInt(NO_CHARACTERS, noCharacters);
        editor.apply();

        //actualizarea UI-ului
        setTextViewUpdatedAt(updatedAt);
        setTextViewNoCharacters(noCharacters);
    }

    private void loadNotesSharedPreference() {
        //citirea din fisierul de preferinte
        String notes = preferences.getString(NOTES, "");
        String updatedAt = preferences.getString(UPDATED_AT, "NONE");
        int noCharacters = preferences.getInt(NO_CHARACTERS, 0);
        //actualizare componente vizuale
        tietNotes.setText(notes);
        setTextViewUpdatedAt(updatedAt);
        setTextViewNoCharacters(noCharacters);
    }

    private boolean isValid() {
        if (tietNotes.getText() == null || tietNotes.getText().toString().length() > 1000) {
            Toast.makeText(getApplicationContext(), R.string.main_no_characters_error_message, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void setTextViewUpdatedAt(String updatedAt) {
        tvUpdatedAt.setText(getString(R.string.main_updated_at_template, updatedAt));
    }

    private void setTextViewNoCharacters(int noCharacters) {
        tvNoCharacters.setText(getString(R.string.main_no_characters_template, noCharacters));
    }
}