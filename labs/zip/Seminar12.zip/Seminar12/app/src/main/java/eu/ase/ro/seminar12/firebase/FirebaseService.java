package eu.ase.ro.seminar12.firebase;

import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import eu.ase.ro.seminar12.util.Callback;
import eu.ase.ro.seminar12.util.Student;

public class FirebaseService {

    public static final String STUDENT_REFERENCE = "students";
    private final DatabaseReference reference;

    private static FirebaseService firebaseService;

    private FirebaseService() {
        reference = FirebaseDatabase.getInstance().getReference(STUDENT_REFERENCE);
    }

    public static FirebaseService getInstance() {
        if (firebaseService == null) {
            synchronized (FirebaseService.class) {
                if (firebaseService == null) {
                    firebaseService = new FirebaseService();
                }
            }
        }
        return firebaseService;
    }

    public void insert(Student student) {
        //validam obiectul student. Ca sa putem face insert trebuie sa NU avem id
        if (student == null || (student.getId() != null && !student.getId().trim().isEmpty())) {
            return;
        }
        //adaugam o cheie noua in Firebase. Mare atentie, aceasta nu contine valorile obiectului student
        String id = reference.push().getKey();
        student.setId(id);
        //ne pozitionam pe id-ul adaugat la linia 46
        //setValue asigura adaugarea informatiilor stocate in copilul pozitionat
        reference.child(student.getId()).setValue(student);
    }

    public void update(Student student) {
        //validam obiectul student. Ca sa putem face update trebuie sa avem id
        if (student == null || student.getId() == null || student.getId().trim().isEmpty()) {
            return;
        }

        //setValue asigura suprascrierea informatiilor stocate in copilul pozitionat prin child.
        reference.child(student.getId()).setValue(student);
    }

    public void delete(Student student) {
        //validam obiectul student. Ca sa putem face delete trebuie sa avem id
        if (student == null || student.getId() == null || student.getId().trim().isEmpty()) {
            return;
        }
        //ne pozitionam pe un copil din students (cel pe care l-am primit in obiectul student)
        //removeValue asigura stergerea informatiilor stocate in copilul pozitionat
        reference.child(student.getId()).removeValue();
    }

    public void attachDataChangeEventListener(Callback<List<Student>> callback) {
        //evenimentul este atasat la nivel de students (reference).
        //Prin urmare asculta orice modificare de insert/update/delete executata asupra acestui nod
        //Apelul metodelor de mai sus forteaza primirea unei notificari de la Firebase in acest eveniment
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Student> students = new ArrayList<>();
                //parcurgem lista de subnoduri din cel principal
                for (DataSnapshot data : snapshot.getChildren()) {
                    //folosim reflection pentru convertirea de la Snapshot la Student
                    //Mare atentie sa definim in Student un constructor default + getteri si setteri
                    Student student = data.getValue(Student.class);
                    if (student != null) {
                        students.add(student);
                    }
                }
                //trimitem lista catre activitatea prin intermediul callback-ului
                callback.runResultOnUiThread(students);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseService", "Data is not available");
            }
        });

        // se poate apela daca dorim sa intersectam doar stergerea obiectelor.
        // nu functioneaza in paralel cu addEventListener
        /*

        reference.removeEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.i("FirebaseService", snapshot.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseService", "Data is not available");
            }
        });

        */
    }
}