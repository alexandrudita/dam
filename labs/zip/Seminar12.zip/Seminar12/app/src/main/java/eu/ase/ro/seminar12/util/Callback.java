package eu.ase.ro.seminar12.util;

public interface Callback<R> {
    void runResultOnUiThread(R result);
}
