package eu.ase.ro.seminar12;

import android.os.Bundle;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar12.util.ChartView;
import eu.ase.ro.seminar12.util.Student;

public class ChartActivity extends AppCompatActivity {

    public static final String STUDENT_KEY = "studentKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        List<Student> students = (List<Student>) getIntent().getSerializableExtra(STUDENT_KEY);
        setContentView(new ChartView(getApplicationContext(), getSource(students)));
    }

    private Map<String, Integer> getSource(List<Student> students) {
        if (students == null || students.isEmpty()) {
            return new HashMap<>();
        }
        Map<String, Integer> source = new HashMap<>();
        for (Student student : students) {
            if (source.containsKey(student.getFaculty())) {
                Integer currentValue = source.get(student.getFaculty());
                source.put(student.getFaculty(), currentValue + 1);
            } else {
                source.put(student.getFaculty(), 1);
            }
        }
        return source;
    }
}