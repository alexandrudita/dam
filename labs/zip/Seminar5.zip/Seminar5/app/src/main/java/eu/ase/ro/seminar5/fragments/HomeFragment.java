package eu.ase.ro.seminar5.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import androidx.fragment.app.Fragment;
import eu.ase.ro.seminar5.R;
import eu.ase.ro.seminar5.util.Expense;

public class HomeFragment extends Fragment {

    private static final String EXPENSES_KEY = "EXPENSES_KEY";

    private ArrayList<Expense> expenses;
    private ListView lvExpenses;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(ArrayList<Expense> expenses) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(EXPENSES_KEY, expenses);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            expenses = getArguments().getParcelableArrayList(EXPENSES_KEY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        initComponents(view);
        return view;
    }

    private void initComponents(View view) {
        lvExpenses = view.findViewById(R.id.home_lv_expenses);
        if (getContext() != null) {
            //getContext() referinta catre activitatea (in cazul nostru MainActivity) de care apartine instanta de HomeFragment
            //echivalent ar fi this
            ArrayAdapter<Expense> adapter = new ArrayAdapter<>(getContext().getApplicationContext(),
                    android.R.layout.simple_list_item_1, expenses);
            lvExpenses.setAdapter(adapter);
        }
    }

    public void notifyAdapter() {
        ArrayAdapter<Expense> adapter = (ArrayAdapter<Expense>) lvExpenses.getAdapter();
        adapter.notifyDataSetChanged();
    }
}