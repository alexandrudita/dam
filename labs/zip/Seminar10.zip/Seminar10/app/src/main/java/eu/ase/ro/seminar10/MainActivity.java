package eu.ase.ro.seminar10;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar10.async.Callback;
import eu.ase.ro.seminar10.database.Expense;
import eu.ase.ro.seminar10.database.ExpenseService;
import eu.ase.ro.seminar10.util.ExpenseAdapter;

public class MainActivity extends AppCompatActivity {

    private ListView lvExpenses;
    private FloatingActionButton fabAddExpense;

    private List<Expense> expenses = new ArrayList<>();
    private ActivityResultLauncher<Intent> addExpenseLauncher;
    private ActivityResultLauncher<Intent> updateExpenseLauncher;

    private ExpenseService expenseService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        addExpenseLauncher = getAddExpenseLauncher();
        updateExpenseLauncher = getUpdateExpenseLauncher();
        //initializare ExpenseService pentru procesari asupra tabelei Expense
        expenseService = new ExpenseService(getApplicationContext());
        //selectarea tuturor cheltuielilor
        expenseService.getAll(getAllExpensesCallback());
        //apelare V2
        //expenseService.getAllV2(getAllExpensesCallback());
    }

    private ActivityResultLauncher<Intent> getUpdateExpenseLauncher() {
        ActivityResultCallback<ActivityResult> callback = getUpdateExpenseActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getUpdateExpenseActivityResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result != null && result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Expense expense = (Expense) result.getData().getSerializableExtra(AddExpenseActivity.EXPENSE_KEY);
                    //update in baza de date
                    expenseService.update(expense, updateExpenseCallback());
                }
            }
        };
    }

    private ActivityResultLauncher<Intent> getAddExpenseLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddExpenseActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddExpenseActivityResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result != null && result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Expense expense = (Expense) result.getData().getSerializableExtra(AddExpenseActivity.EXPENSE_KEY);
                    //inserare in baza de date
                    expenseService.insert(expense, getInsertExpenseCallback());
                    //apelare varianta v2
                    //expenseService.insertV2(expense, getInsertExpenseCallback());
                }
            }
        };
    }

    private void initComponents() {
        lvExpenses = findViewById(R.id.main_lv_expenses);
        fabAddExpense = findViewById(R.id.main_fab_add_expense);
        addAdapter();
        fabAddExpense.setOnClickListener(addExpenseEventListener());
        lvExpenses.setOnItemClickListener(getItemClickEvent());
        lvExpenses.setOnItemLongClickListener(getItemLongClickEvent());
    }

    private AdapterView.OnItemLongClickListener getItemLongClickEvent() {
        return new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //stergere element
                expenseService.delete(expenses.get(position), deleteExpenseCallback(position));
                return true;
            }
        };
    }

    private AdapterView.OnItemClickListener getItemClickEvent() {
        return new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                intent.putExtra(AddExpenseActivity.EXPENSE_KEY, expenses.get(position));
                updateExpenseLauncher.launch(intent);
            }
        };
    }

    private View.OnClickListener addExpenseEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                addExpenseLauncher.launch(intent);
            }
        };
    }

    private void addAdapter() {
        ExpenseAdapter adapter = new ExpenseAdapter(getApplicationContext(), R.layout.lv_expense_row,
                expenses, getLayoutInflater());
        lvExpenses.setAdapter(adapter);
    }

    private void notifyAdapter() {
        ExpenseAdapter adapter = (ExpenseAdapter) lvExpenses.getAdapter();
        adapter.notifyDataSetChanged();
    }


    //------------------------------ SQLite -------------------------------------
    private Callback<Expense> getInsertExpenseCallback() {
        return new Callback<Expense>() {
            @Override
            public void runResultOnUiThread(Expense expense) {
                //aici suntem notificati din thread-ul secundar cand operatia de adaugare in baza de date s-a executat
                if (expense != null) {
                    expenses.add(expense);
                    notifyAdapter();
                }
            }
        };
    }

    private Callback<List<Expense>> getAllExpensesCallback() {
        return new Callback<List<Expense>>() {
            @Override
            public void runResultOnUiThread(List<Expense> results) {
                if (results != null) {
                    expenses.clear();
                    expenses.addAll(results);
                    notifyAdapter();
                }
            }
        };
    }

    private Callback<Expense> updateExpenseCallback() {
        return new Callback<Expense>() {
            @Override
            public void runResultOnUiThread(Expense result) {
                if (result != null) {
                    //actualizare ListView
                    for (Expense expense : expenses) {
                        if (expense.getId() == result.getId()) {
                            expense.setDate(result.getDate());
                            expense.setAmount(result.getAmount());
                            expense.setCategory(result.getCategory());
                            expense.setDescription(result.getDescription());
                            break;
                        }
                    }
                    notifyAdapter();
                }
            }
        };
    }

    private Callback<Boolean> deleteExpenseCallback(int position) {
        return new Callback<Boolean>() {
            @Override
            public void runResultOnUiThread(Boolean result) {
                if (result) {
                    expenses.remove(position);
                    notifyAdapter();
                }
            }
        };
    }
}