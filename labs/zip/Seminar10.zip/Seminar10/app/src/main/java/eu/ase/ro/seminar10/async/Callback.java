package eu.ase.ro.seminar10.async;

public interface Callback<R>{
    void runResultOnUiThread(R result);
}
