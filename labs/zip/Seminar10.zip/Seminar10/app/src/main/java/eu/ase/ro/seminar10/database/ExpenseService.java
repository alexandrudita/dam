package eu.ase.ro.seminar10.database;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.Callable;

import eu.ase.ro.seminar10.async.AsyncTaskRunner;
import eu.ase.ro.seminar10.async.Callback;

public class ExpenseService {

    private final ExpenseDao expenseDao;
    private final AsyncTaskRunner asyncTaskRunner;

    public ExpenseService(Context context) {
        this.expenseDao = DatabaseManager.getInstance(context).getExpenseDao();
        this.asyncTaskRunner = new AsyncTaskRunner();
    }

    public void insert(Expense expense, Callback<Expense> activityThread) {
        //operation executata pe un alt thread
        Callable<Expense> insertOperation = new Callable<Expense>() {
            @Override
            public Expense call() {
                if (expense == null || expense.getId() > 0) {
                    return null;
                }
                long id = expenseDao.insert(expense);
                if (id < 0) { //ceva nu a functionat in scriptul de insert
                    return null;
                }
                expense.setId(id);
                return expense;
            }
        };

        //pornire thread secundar
        asyncTaskRunner.executeAsync(insertOperation, activityThread);
    }

    public void getAll(Callback<List<Expense>> activityThread) {
        Callable<List<Expense>> selectOperation = new Callable<List<Expense>>() {
            @Override
            public List<Expense> call() {
                return expenseDao.getAll();
            }
        };

        asyncTaskRunner.executeAsync(selectOperation, activityThread);
    }

    public void update(Expense expense, Callback<Expense> activityThread) {
        Callable<Expense> updateOperation = new Callable<Expense>() {
            @Override
            public Expense call() {
                if (expense == null || expense.getId() <= 0) {
                    return null;
                }
                int count = expenseDao.update(expense);
                if (count <= 0) {
                    return null;
                }
                return expense;
            }
        };

        asyncTaskRunner.executeAsync(updateOperation, activityThread);
    }

    public void delete(Expense expense, Callback<Boolean> activityThread) {
        Callable<Boolean> deleteOperation = new Callable<Boolean>() {
            @Override
            public Boolean call() {
                if (expense == null || expense.getId() <= 0) {
                    return false;
                }
                int count = expenseDao.delete(expense);
                return count > 0;
            }
        };

        asyncTaskRunner.executeAsync(deleteOperation, activityThread);
    }


    //------------------------------ Exemplu de apelul folosind Thread in loc de AsyncTaskRunner---------------------
    public void getAllV2(Callback<List<Expense>> activityThread) {
        new Thread() {
            @Override
            public void run() {
                List<Expense> expenses = expenseDao.getAll();
                sendDatabaseResponseToActivityThread(expenses, activityThread);
            }
        }.start();
    }

    public void insertV2(Expense expense, Callback<Expense> activityThread) {
        new Thread() {
            @Override
            public void run() {
                if (expense == null || expense.getId() > 0) {
                    sendDatabaseResponseToActivityThread(null, activityThread);
                    return;
                }
                long id = expenseDao.insert(expense);
                if (id < 0) {
                    sendDatabaseResponseToActivityThread(null, activityThread);
                    return;
                }
                expense.setId(id);
                sendDatabaseResponseToActivityThread(expense, activityThread);
            }
        }.start();
    }

    private <R> void sendDatabaseResponseToActivityThread(R result, Callback<R> activityThread) {

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                activityThread.runResultOnUiThread(result);
            }
        });
    }
}
