package eu.ase.ro.seminar10.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface ExpenseDao {

    @Insert
    long insert(Expense expense);

    @Query("select * from expenses")
    List<Expense> getAll();

    @Update
    int update(Expense expense);

    @Delete
    int delete(Expense expense);
}
