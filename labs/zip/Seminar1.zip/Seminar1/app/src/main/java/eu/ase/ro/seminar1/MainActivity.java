package eu.ase.ro.seminar1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //asocierea fisierului xml din res/layout care reprezinta aspectul vizual a activitatii curente.
        setContentView(R.layout.activity_main);
        Log.i("MainActivity", "Call onCreate");

        //initializare variabilele java cu id-urile componentelor vizuale din activity_main.xml (ne uitam dupa android:id)
        tvMessage = findViewById(R.id.main_tv_message);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //atasarea unui meniu intr-o activitate
        //inflate asociaza fisierul din res/menu cu un obiect Java de tipul Menu, astfel incat
        // sa se poata intercepta actiunile utilizatorilor de la nivelul meniului (optiunea selectata)
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //identificarea optiunii din meniu apasata de utilizator
        if (item.getItemId() == R.id.menu_option_1) {
            Toast.makeText(getApplicationContext(), R.string.option_1,
                    Toast.LENGTH_LONG).show();
            tvMessage.setTextColor(Color.RED);
        } else if (item.getItemId() == R.id.menu_option_2) {
            Toast.makeText(getApplicationContext(), R.string.option_2,
                    Toast.LENGTH_LONG).show();
            tvMessage.setTextColor(Color.BLUE);
        }

        tvMessage.setText(item.getTitle());
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("MainActivity", "Call onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("MainActivity", "Call onResume");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("MainActivity", "Call onDestroy");
    }
}