package eu.ase.ro.seminar8.network;

public interface Callback<R> {

    void runResultOnUiThread(R result);
}
