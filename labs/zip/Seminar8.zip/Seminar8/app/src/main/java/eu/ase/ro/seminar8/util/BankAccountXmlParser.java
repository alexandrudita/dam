package eu.ase.ro.seminar8.util;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class BankAccountXmlParser {

    public static final String BANK_NAME_TAG = "bankName";
    public static final String CARD_HOLDER_NAME_TAG = "cardHolderName";
    public static final String CARD_NUMBER_TAG = "cardNumber";
    public static final String EXPIRATION_MONTH_TAG = "expirationMonth";
    public static final String EXPIRATION_YEAR_TAG = "expirationYear";
    public static final String BANK_ACCOUNT_TAG = "bankAccount";

    public static List<BankAccount> fromXml(String xml) {
        if (xml == null) {
            return new ArrayList<>();
        }
        xml = xml.replace("\"", "");
        List<BankAccount> results = new ArrayList<>();
        try {
            readBankAccounts(xml, results);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    private static void readBankAccounts(String xml, List<BankAccount> results) throws XmlPullParserException, IOException {
        String value = null;
        int event;
        BankAccount account = new BankAccount();
        //creare parser
        XmlPullParser xmlParser = Xml.newPullParser();
        xmlParser.setInput(new StringReader(xml));
        event = xmlParser.getEventType();
        //aceasta librarie interpreteaza fiecare componenta in parte a xml-ului. Astfel putem intalni urmatoarele date: tag de start (Ex <bankAccount ...>),
        // tag de sfarsit (Ex: </bankAccount>) si valoare (Ex: ING);
        while (event != XmlPullParser.END_DOCUMENT) {
            String tagName = xmlParser.getName();
            if (XmlPullParser.START_TAG == event && tagName.equals(BANK_ACCOUNT_TAG)) {
                //este accesat in momentul in care ne aflam pe un tag de start. Ex: <bankAccount>
                //daca tag-ul este bankAccount, atunci ar trebui sa initializam un nou element de acest tip. Metoda noastra intoarce o lista de astfel de obiecte,
                //Prin urmare, acest tag se intalneste o singura data pentru fiecare obiect in parte.
                account = new BankAccount();
            }
            if (XmlPullParser.TEXT == event) {
                // in acest caz ne aflam atunci cand accesam o valoare dintr-un tag frunza. Ex: <cardHolderName>Vasile Mirela</cardHolderName>
                value = xmlParser.getText();
            }
            if (XmlPullParser.END_TAG == event && tagName.equals(BANK_ACCOUNT_TAG)) {
                results.add(account);
            }
            if (XmlPullParser.END_TAG == event && value != null && !value.trim().isEmpty()) {
                buildBankAccount(account, tagName, value);
            }
            //se acceseaza urmatoarea componenta a xml.
            event = xmlParser.next();
        }
    }

    private static void buildBankAccount(BankAccount account, String tagName, String value) {
        // Cand va aflati in aceasta situatie stiti ce valoare este salvata in variabila 'value' in tag-ul XmlPullParser.Text
        switch (tagName) {
            case BANK_NAME_TAG:
                //Ex de tag: </bankName>. Adaugam valoare in obiectul item.
                account.setBankName(value);
                break;
            case CARD_HOLDER_NAME_TAG:
                account.setCardHolderName(value);
                break;
            case CARD_NUMBER_TAG:
                account.setCardNumber(Long.parseLong(value));
                break;
            case EXPIRATION_MONTH_TAG:
                account.setExpirationMonth(Integer.parseInt(value));
                break;
            case EXPIRATION_YEAR_TAG:
                account.setExpirationYear(Integer.parseInt(value));
                break;
        }
    }

}
