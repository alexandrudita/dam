package eu.ase.ro.seminar8;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import eu.ase.ro.seminar8.network.AsyncTaskRunner;
import eu.ase.ro.seminar8.network.Callback;
import eu.ase.ro.seminar8.network.HttpManager;
import eu.ase.ro.seminar8.util.BankAccount;
import eu.ase.ro.seminar8.util.BankAccountAdapter;
import eu.ase.ro.seminar8.util.BankAccountJsonParser;
import eu.ase.ro.seminar8.util.BankAccountXmlParser;

public class MainActivity extends AppCompatActivity {

    private final static String BANK_ACCOUNT_URL = "https://jsonkeeper.com/b/PE13";
    private final static String BANK_ACCOUNT_XML_URL = "https://jsonkeeper.com/b/ZW1O";
    private ListView lvBankAccounts;
    private List<BankAccount> bankAccounts = new ArrayList<>();

    private final AsyncTaskRunner asyncTaskRunner = new AsyncTaskRunner();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        bankAccounts.add(new BankAccount("FAKE 1",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("FAKE2",
                1234567890123456L, 3, 2022, "BRD"));
        loadBankAccountsFromHttp();
    }

    private void initComponents() {
        lvBankAccounts = findViewById(R.id.main_lv_bank_accounts);
        addBankAccountAdapter();
    }

    private void addBankAccountAdapter() {
        BankAccountAdapter adapter = new BankAccountAdapter(getApplicationContext(), R.layout.lv_row_view, bankAccounts, getLayoutInflater());
        lvBankAccounts.setAdapter(adapter);
    }

    private void loadBankAccountsFromHttp() {
        //definim un obiect de tip Callable pe care dorim sa-l procesam pe un alt fir de executie
        //HttpManager implementeaza aceasta interfata.
        Callable<String> asyncOperation = new HttpManager(BANK_ACCOUNT_URL);
        //definim Callback-ul, adica zona din activitatea unde dorim sa receptionam rezultatul procesarii paralele
        //realizata de Callable
        Callback<String> mainThreadOperation = getMainThreadOperation();
        //Apelam asyncTaskRunner cu operatia asincrona si zona de cod din activitate unde dorim sa primim raspunsul
        asyncTaskRunner.executeAsync(asyncOperation, mainThreadOperation);

        Callable<String> asyncOperationXml = new HttpManager(BANK_ACCOUNT_XML_URL);
        Callback<String> mainThreadOperationXml = getMainThreadOperationXml();
        asyncTaskRunner.executeAsync(asyncOperationXml, mainThreadOperationXml);
    }

    @NonNull
    private Callback<String> getMainThreadOperationXml() {
        return new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                //apelam parsatorul de xml, iar rezultatul obtinut il adaugam in lista de obiecte BankAccount
                bankAccounts.addAll(BankAccountXmlParser.fromXml(result));
                //avand in vedere ca lista de obiecte este modificata la linia de mai sus,
                // este necesar sa notificam adapterul de acest lucru astfel incat obiectele noi
                //sa fie incarcate in ListView
                notifyAdapter();
            }
        };
    }

    @NonNull
    private Callback<String> getMainThreadOperation() {
        return new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                //apelam parsatorul de json, iar rezultatul obtinut il adaugam in lista de obiecte BankAccount
                //existenta la nivelul activitati
                bankAccounts.addAll(BankAccountJsonParser.fromJson(result));
                //avand in vedere ca lista de obiecte este modificata la linia de mai sus,
                // este necesar sa notificam adapterul de acest lucru astfel incat obiectele noi
                //sa fie incarcate in ListView
                notifyAdapter();
            }
        };
    }

    private void notifyAdapter() {
        BankAccountAdapter adapter = (BankAccountAdapter) lvBankAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }
}