package eu.ase.ro.seminar4;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
    }

    private void initComponents() {
        configNavigation();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(getNavigationItemSelectedListener());
    }

    private NavigationView.OnNavigationItemSelectedListener getNavigationItemSelectedListener() {
        return new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.main_nav_home) {
                    Log.i("MainActivity", "Home is selected");
                } else if (item.getItemId() == R.id.main_nav_contact) {
                    Log.i("MainActivity", "Contact is selected");
                }
                Toast.makeText(getApplicationContext(), getString(R.string.main_message,item.getTitle()), Toast.LENGTH_SHORT).show();
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        };
    }

    private void configNavigation() {
        drawerLayout = findViewById(R.id.drawer_layout);
        //definim Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        //atasare toolbar activitate la nivel de cod Java
        setSupportActionBar(toolbar);
        //definim toggle -> burgerMenu din interfata
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawerLayout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        //setam la nivelul drawerLayout un listener -> drawerLayout trebuie sa fie notificat de actiunile toggle-ului
        drawerLayout.addDrawerListener(toggle);
        //sincronizarea starii la nivel de toggle
        toggle.syncState();
    }
}