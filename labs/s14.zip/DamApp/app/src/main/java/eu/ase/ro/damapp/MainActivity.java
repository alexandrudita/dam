package eu.ase.ro.damapp;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapp.util.Callback;
import eu.ase.ro.damapp.util.Student;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText tietName;
    private Spinner spnFaculty;
    private Button btnClearFields;
    private FloatingActionButton fabDelete;
    private FloatingActionButton fabSave;
    private ListView lvStudents;

    private List<Student> students = new ArrayList<>();

    private int selectedStudentIndex = -1;

    private final FirebaseService firebaseService = new FirebaseService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        //citire/actualizare date din firebase in timp real. (orice operatie de adaugare, sterger sau modificare
        //declanseaza pronirea acestui eveniment.
        firebaseService.attachDataChangeEventListener(getStudentChangeCallback());
    }

    private Callback<List<Student>> getStudentChangeCallback() {
        return new Callback<List<Student>>() {
            @Override
            public void runResultOnUiThread(List<Student> results) {
                if (results != null) {
                    students.clear();
                    students.addAll(results);
                    notifyListViewStudentAdapter();
                    clearFields();
                }
            }
        };
    }

    private void initComponents() {
        tietName = findViewById(R.id.main_tiet_name);
        spnFaculty = findViewById(R.id.main_spn_faculties);
        btnClearFields = findViewById(R.id.main_btn_clear_fields);
        fabDelete = findViewById(R.id.main_fab_delete);
        fabSave = findViewById(R.id.main_fab_save);
        lvStudents = findViewById(R.id.main_lv_students);
        addSpinnerFacultiesAdapter();
        addListViewStudentsAdapter();
        btnClearFields.setOnClickListener(getClearFieldsClickEvent());
        fabSave.setOnClickListener(getSaveStudentClickEvent());
        fabDelete.setOnClickListener(getDeleteStudentClickEvent());
        lvStudents.setOnItemClickListener(getSelectStudentClickEvent());
    }

    private View.OnClickListener getClearFieldsClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        };
    }

    private View.OnClickListener getSaveStudentClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    if (selectedStudentIndex == -1) {
                        Student student = new Student();
                        updateStudentFromView(student);
                        students.add(student);
                        firebaseService.insert(student);
                    } else {
                        Student updatedStudent = students.get(selectedStudentIndex);
                        updateStudentFromView(updatedStudent);
                        firebaseService.update(updatedStudent);
                    }
                }
            }
        };
    }

    private View.OnClickListener getDeleteStudentClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedStudentIndex != -1) {
                    Student deletedStudent = students.get(selectedStudentIndex);
                    firebaseService.delete(deletedStudent);
                }
            }
        };
    }

    private AdapterView.OnItemClickListener getSelectStudentClickEvent() {
        return new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedStudentIndex = position;
                Student student = students.get(position);
                tietName.setText(student.getName());
                selectFaculty(student.getFaculty());
            }
        };
    }

    private boolean isValid() {
        if (tietName.getText() == null || tietName.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.main_invalid_name_error, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void updateStudentFromView(Student student) {
        student.setName(tietName.getText().toString());
        student.setFaculty((String) spnFaculty.getSelectedItem());
    }

    private void addSpinnerFacultiesAdapter() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.faculties_options, android.R.layout.simple_spinner_dropdown_item);
        spnFaculty.setAdapter(adapter);
    }

    private void addListViewStudentsAdapter() {
        ArrayAdapter<Student> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, students);
        lvStudents.setAdapter(adapter);
    }

    private void notifyListViewStudentAdapter() {
        ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
        adapter.notifyDataSetChanged();
    }

    private void selectFaculty(String faculty) {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) spnFaculty.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            if (adapter.getItem(i).equals(faculty)) {
                spnFaculty.setSelection(i);
                break;
            }
        }
    }

    private void clearFields() {
        tietName.setText(null);
        spnFaculty.setSelection(0);
        selectedStudentIndex = -1;
    }

}