package eu.ase.ro.damapp.util;

public interface Callback<R> {

    void runResultOnUiThread(R result);
}
