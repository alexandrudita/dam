package eu.ase.ro.damappfirebase;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import eu.ase.ro.damappfirebase.util.Student;


public class FirebaseService {

    public static final String STUDENT_REFERENCE = "students";
    private final DatabaseReference reference;

    private static FirebaseService firebaseService;

    private FirebaseService() {
        reference = FirebaseDatabase.getInstance().getReference(STUDENT_REFERENCE);
    }

    public static FirebaseService getInstance() {
        if (firebaseService == null) {
            synchronized (FirebaseService.class) {
                if (firebaseService == null) {
                    firebaseService = new FirebaseService();
                }
            }
        }
        return firebaseService;
    }

    public void insert(Student student) {
        if (student == null || (student.getId() != null && !student.getId().trim().isEmpty())) {
            return;
        }
        String id = reference.push().getKey();
        student.setId(id);
        reference.child(student.getId()).setValue(student);
    }
}