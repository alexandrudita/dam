package eu.ase.ro.damapproom.async;

public interface Callback<R> {

    void runResultOnUiThread(R result);
}
