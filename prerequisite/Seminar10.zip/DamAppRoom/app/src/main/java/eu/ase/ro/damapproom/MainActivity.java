package eu.ase.ro.damapproom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapproom.util.Expense;
import eu.ase.ro.damapproom.util.ExpenseAdapter;

public class MainActivity extends AppCompatActivity {

    public static final String UPDATED_POSITION = "updatedPosition";
    public static final String ACTION = "action";
    public static final String UPDATE_ACTION = "update";
    public static final String ADD_ACTION = "add";
    private ListView lvExpenses;
    private FloatingActionButton fabAddExpense;

    private List<Expense> expenses = new ArrayList<>();
    private ActivityResultLauncher<Intent> launcher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        launcher = getLauncher();
    }

    private void initComponents() {
        lvExpenses = findViewById(R.id.main_lv_expenses);
        fabAddExpense = findViewById(R.id.main_fab_add_expense);
        addAdapter();
        fabAddExpense.setOnClickListener(getAddExpenseEventListener());
        lvExpenses.setOnItemClickListener(getItemClickEventListener());
        lvExpenses.setOnItemLongClickListener(getItemLongClickEventListener());
    }

    private ActivityResultLauncher<Intent> getLauncher() {
        ActivityResultCallback<ActivityResult> callback = getExpenseActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getExpenseActivityResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getData() == null || result.getResultCode() != RESULT_OK) {
                    return;
                }
                Expense expense = (Expense) result.getData().getSerializableExtra(AddExpenseActivity.EXPENSE_KEY);
                if (ADD_ACTION.equals(result.getData().getStringExtra(ACTION))) {
                    expenses.add(expense);
                    notifyAdapter();
                } else if (UPDATE_ACTION.equals(result.getData().getStringExtra(ACTION))) {
                    int position = result.getData().getIntExtra(UPDATED_POSITION, 0);
                    expenses.get(position).setCategory(expense.getCategory());
                    expenses.get(position).setDate(expense.getDate());
                    expenses.get(position).setAmount(expense.getAmount());
                    expenses.get(position).setDescription(expense.getDescription());
                    notifyAdapter();
                }
            }
        };
    }

    private AdapterView.OnItemClickListener getItemClickEventListener() {
        return new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                intent.putExtra(AddExpenseActivity.EXPENSE_KEY, expenses.get(i));
                intent.putExtra(UPDATED_POSITION, i);
                intent.putExtra(ACTION, UPDATE_ACTION);
                launcher.launch(intent);
            }
        };
    }

    private AdapterView.OnItemLongClickListener getItemLongClickEventListener() {
        return new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                expenses.remove(i);
                notifyAdapter();
                return true;
            }
        };
    }

    private View.OnClickListener getAddExpenseEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                intent.putExtra(ACTION, ADD_ACTION);
                launcher.launch(intent);
            }
        };
    }

    private void addAdapter() {
        ExpenseAdapter adapter = new ExpenseAdapter(getApplicationContext(), R.layout.lv_row_item, expenses, getLayoutInflater());
        lvExpenses.setAdapter(adapter);
    }

    private void notifyAdapter() {
        ExpenseAdapter adapter = (ExpenseAdapter) lvExpenses.getAdapter();
        adapter.notifyDataSetChanged();
    }
}