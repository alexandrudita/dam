package eu.ase.ro.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapp.util.BankAccount;
import eu.ase.ro.damapp.util.BankAccountAdapter;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fabAdd;
    private ListView lvAccounts;

    private ActivityResultLauncher<Intent> addLauncher;

    private List<BankAccount> bankAccounts = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
        addLauncher = registerAddLauncher();
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 3, 2022, "BRD"));
    }

    private void initComponents() {
        fabAdd = findViewById(R.id.main_fab_add);
        lvAccounts = findViewById(R.id.main_lv_bank_accounts);

        fabAdd.setOnClickListener(getAddEvent());
        BankAccountAdapter adapter = new BankAccountAdapter(getApplicationContext(), R.layout.lv_row_item, bankAccounts, getLayoutInflater());
        lvAccounts.setAdapter(adapter);
    }

    private View.OnClickListener getAddEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                addLauncher.launch(intent);
            }
        };
    }

    private ActivityResultLauncher<Intent> registerAddLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddBankAccountResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddBankAccountResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    BankAccount account = (BankAccount) result.getData().getSerializableExtra(AddActivity.BANK_ACCOUNT_KEY);
                    bankAccounts.add(account);
                    notifyAdapter();
                }
            }
        };
    }

    private void notifyAdapter() {
        BankAccountAdapter adapter = (BankAccountAdapter) lvAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }
}