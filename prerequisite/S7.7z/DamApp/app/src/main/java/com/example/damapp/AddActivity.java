package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatSpinner;

import com.example.damapp.model.Student;
import com.example.damapp.model.StudyType;
import com.example.damapp.util.DateConverter;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_STUDENT_KEY = "ADD_STUDENT_KEY";
    private Intent intent;

    private AppCompatButton btnSave;
    private TextInputEditText tietName;
    private TextInputEditText tietEnrollmentDate;
    private AppCompatSpinner spnFaculty;
    private RadioGroup rgStudyType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        initComponents();
    }

    private void initComponents() {
        //pasul 2 din schema
        intent = getIntent();

        btnSave = findViewById(R.id.add_btn_save);
        btnSave.setOnClickListener(getSaveListener());

        tietName = findViewById(R.id.add_tiet_name);
        tietEnrollmentDate = findViewById(R.id.add_tiet_enrollment_date);
        spnFaculty = findViewById(R.id.add_spn_faculties);
        rgStudyType = findViewById(R.id.add_rg_study_type);
    }

    private View.OnClickListener getSaveListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValid()) {
                    //construiesc student
                    Student student = buildStudent();
                    //aici facem pasul 3 din schema
                    intent.putExtra(ADD_STUDENT_KEY,
                            student);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private Student buildStudent() {
        String name = tietName.getText().toString();
        Date enrollmentDate = DateConverter.toDate(
                tietEnrollmentDate.getText()
                        .toString());
        String faculty = (String) spnFaculty
                .getSelectedItem();
        StudyType studyType =
                rgStudyType.getCheckedRadioButtonId()
                        == R.id.add_rb_full_time
                        ? StudyType.FULL_TIME
                        : StudyType.DISTANCE;

        return new Student(name, enrollmentDate,
                faculty, studyType);
    }

    private boolean isValid() {
        if (tietName.getText() == null || tietName.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(), R.string.invalid_name_minim_3_characters, Toast.LENGTH_LONG).show();
            return false;
        }
        //dd-MM-yyyy
        if (tietEnrollmentDate.getText() == null || DateConverter.toDate(tietEnrollmentDate.getText().toString()) == null) {
            Toast.makeText(getApplicationContext(), R.string.invalid_enrollment_date_accepted_dd_mm_yyyy, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}