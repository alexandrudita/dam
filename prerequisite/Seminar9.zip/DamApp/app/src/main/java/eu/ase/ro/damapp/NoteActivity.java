package eu.ase.ro.damapp;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

import eu.ase.ro.damapp.util.DateConverter;

public class NoteActivity extends AppCompatActivity {

    private TextView tvUpdatedAt;
    private TextView tvNoCharacters;
    private TextInputEditText tietNotes;
    private FloatingActionButton fabSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        initComponents();
    }

    private void initComponents() {
        tvUpdatedAt = findViewById(R.id.note_tv_updated_at);
        tvNoCharacters = findViewById(R.id.note_tv_no_characters);
        tietNotes = findViewById(R.id.note_tiet_notes);
        fabSave = findViewById(R.id.note_fab_save);
        fabSave.setOnClickListener(getSavedClickEvent());
    }

    private View.OnClickListener getSavedClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValid()) {
                    Toast.makeText(getApplicationContext(), R.string.save_pushed_message, Toast.LENGTH_SHORT).show();
                    String updateAt = DateConverter.fromDate(new Date());
                    String notes = tietNotes.getText().toString();
                    tvUpdatedAt.setText(getString(R.string.note_updated_at_template, updateAt));
                    tvNoCharacters.setText(getString(R.string.note_no_characters_template, notes.length()));
                }
            }
        };
    }

    private boolean isValid() {
        if (tietNotes.getText() == null || tietNotes.getText().toString().length() > 1000) {
            Toast.makeText(getApplicationContext(), R.string.note_no_characters_error_message, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}