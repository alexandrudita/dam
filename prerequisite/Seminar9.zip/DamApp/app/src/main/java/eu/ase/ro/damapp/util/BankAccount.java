package eu.ase.ro.damapp.util;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.Locale;

public class BankAccount implements Serializable {
    private String cardHolderName;
    private long cardNumber;
    private int expirationMonth;
    private int expirationYear;
    private String bankName;

    public BankAccount(String cardHolderName, long cardNumber, int expirationMonth, int expirationYear, String bankName) {
        this.cardHolderName = cardHolderName;
        this.cardNumber = cardNumber;
        this.expirationMonth = expirationMonth;
        this.expirationYear = expirationYear;
        this.bankName = bankName;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getExpirationMonth() {
        return expirationMonth;
    }

    public void setExpirationMonth(int expirationMonth) {
        this.expirationMonth = expirationMonth;
    }

    public int getExpirationYear() {
        return expirationYear;
    }

    public void setExpirationYear(int expirationYear) {
        this.expirationYear = expirationYear;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @NonNull
    @Override
    public String toString() {
        return String.format(Locale.US, "BankAccount %s %s %d %d/%d",
                cardHolderName, bankName, cardNumber, expirationMonth, expirationYear);
    }
}
