package eu.ase.ro.damapp.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BankAccountJsonParser {

    public static final String BANK_NAME = "bankName";
    public static final String CARD_HOLDER_NAME = "cardHolderName";
    public static final String EXPIRATION_MONTH = "expirationMonth";
    public static final String EXPIRATION_YEAR = "expirationYear";
    public static final String CARD_NUMBER = "cardNumber";

    public static List<BankAccount> fromJson(String json) {
        try {
            JSONArray array = new JSONArray(json);
            return getBankAccounts(array);
        } catch (JSONException e) {
            return new ArrayList<>();
        }
    }

    private static List<BankAccount> getBankAccounts(JSONArray array) throws JSONException {
        List<BankAccount> result = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            BankAccount account = getBankAccount(array.getJSONObject(i));
            result.add(account);
        }
        return result;
    }

    private static BankAccount getBankAccount(JSONObject object) throws JSONException {
        String bankName = object.getString(BANK_NAME);
        String cardHolderName = object.getString(CARD_HOLDER_NAME);
        int expirationMonth = object.getInt(EXPIRATION_MONTH);
        int expirationYear = object.getInt(EXPIRATION_YEAR);
        long cardNumber = object.getLong(CARD_NUMBER);

        return new BankAccount(cardHolderName, cardNumber, expirationMonth, expirationYear, bankName);
    }
}
