package eu.ase.ro.damapp.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.ro.damapp.R;

public class BankAccountAdapter extends ArrayAdapter<BankAccount> {

    private Context context;
    private int resource;
    private List<BankAccount> accounts;
    private LayoutInflater inflater;

    public BankAccountAdapter(@NonNull Context context, int resource, @NonNull List<BankAccount> objects, LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.accounts = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        BankAccount bankAccount = accounts.get(position);

        addBankName(bankAccount.getBankName(), view);
        addCardHolderName(bankAccount.getCardHolderName(), view);
        addCardNumber(bankAccount.getCardNumber(), view);
        addExpiration(bankAccount.getExpirationMonth(), bankAccount.getExpirationYear(), view);

        return view;
    }

    private void addExpiration(int expirationMonth, int expirationYear, View view) {
        TextView textView = view.findViewById(R.id.row_item_tv_expiration);
        String value = context.getString(R.string.row_item_expiration_template, expirationMonth, expirationYear);
        textView.setText(value);
    }

    private void addCardNumber(long cardNumber, View view) {
        TextView textView = view.findViewById(R.id.row_item_tv_card_number);
        textView.setText(String.valueOf(cardNumber));
    }

    private void addCardHolderName(String cardHolderName, View view) {
        TextView textView = view.findViewById(R.id.row_item_tv_card_holder_name);
        textView.setText(calculateTextViewValue(cardHolderName));
    }

    private void addBankName(String bankName, View view) {
        TextView textView = view.findViewById(R.id.row_item_tv_bank_name);
        textView.setText(calculateTextViewValue(bankName));
    }

    private String calculateTextViewValue(String value) {
        if (value == null || value.isEmpty()) {
            return context.getString(R.string.lv_row_item_default_value);
        }

        return value;
    }
}
