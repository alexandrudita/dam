package eu.ase.ro.damapproom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Date;

import eu.ase.ro.damapproom.util.DateConverter;
import eu.ase.ro.damapproom.util.Expense;

public class AddExpenseActivity extends AppCompatActivity {

    public static final String EXPENSE_KEY = "expenseKey";
    private TextInputEditText tietDate;
    private TextInputEditText tietAmount;
    private Spinner spnCategory;
    private TextInputEditText tietDescription;
    private ImageButton ibSave;

    private Expense expense;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);
        initComponents();
        intent = getIntent();
    }

    private void initComponents() {
        tietDate = findViewById(R.id.add_expense_tiet_date);
        tietAmount = findViewById(R.id.add_expense_tiet_amount);
        spnCategory = findViewById(R.id.add_expense_spn_category);
        tietDescription = findViewById(R.id.add_expense_tiet_description);
        ibSave = findViewById(R.id.add_expense_ibtn_save);
        ibSave.setOnClickListener(saveExpenseEventListener());
    }

    private View.OnClickListener saveExpenseEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    createFromViews();
                    intent.putExtra(EXPENSE_KEY, expense);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private boolean isValid() {
        if (tietDate.getText() == null || tietDate.getText().toString().trim().isEmpty()
                || DateConverter.toDate(tietDate.getText().toString()) == null) {
            Toast.makeText(getApplicationContext(),
                            R.string.add_expense_date_error_message,
                            Toast.LENGTH_SHORT)
                    .show();
            return false;
        }
        if (tietAmount.getText() == null || tietAmount.getText().toString().isEmpty()
                || Double.parseDouble(tietAmount.getText().toString()) < 0) {
            Toast.makeText(getApplicationContext(),
                            R.string.add_expense_amount_error_message,
                            Toast.LENGTH_SHORT)
                    .show();
            return false;
        }
        return true;
    }

    private void createFromViews() {
        Date date = DateConverter.toDate(tietDate.getText().toString());
        String category = spnCategory.getSelectedItem().toString();
        Double amount = Double.parseDouble(tietAmount.getText().toString());
        String description = tietDescription.getText().toString();
        expense = new Expense(date, category, amount, description);
    }
}