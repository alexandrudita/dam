package com.example.damapp.network;

public interface Callback <R>{
    void runResultOnUiThread(R result);
}
