package eu.ase.ro.damapproom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapproom.async.Callback;
import eu.ase.ro.damapproom.database.ExpenseService;
import eu.ase.ro.damapproom.util.Expense;
import eu.ase.ro.damapproom.util.ExpenseAdapter;

public class MainActivity extends AppCompatActivity {
    private static final String ACTION_KEY = "actionKey";
    private static final String UPDATED_POSITION_KEY = "updatePositionKey";
    private static final String ADD_ACTION = "add_new_expense";
    private static final String UPDATE_ACTION = "update_new_expense";

    private ListView lvExpenses;
    private FloatingActionButton fabAddExpense;

    private List<Expense> expenses = new ArrayList<>();
    private ActivityResultLauncher<Intent> addExpenseLauncher;

    private ExpenseService expenseService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expenseService = new ExpenseService(getApplicationContext());
        initComponents();
        addExpenseLauncher = getAddExpenseLauncher();
        //selectam toate cheltuielile din baza de date
        expenseService.getAll(getAllCallback());
    }

    //--------------------------- Expense DAO operations - START -------------------------------------

    private Callback<List<Expense>> getAllCallback() {
        return new Callback<List<Expense>>() {
            @Override
            public void runResultOnUiThread(List<Expense> result) {
                //suntem in thread-ul activitatii principale
                expenses.addAll(result);
                notifyAdapter();
            }
        };
    }

    private Callback<Expense> getInsertCallback() {
        return new Callback<Expense>() {
            @Override
            public void runResultOnUiThread(Expense expense) {
                //aici ma aflu pe callbackul de la inser, adica in main thread. am raspunde primit de la baza de date
                if (expense != null) {
                    expenses.add(expense);
                    notifyAdapter();
                }
            }
        };
    }
    //--------------------------- Expense DAO operations - END -------------------------------------

    private ActivityResultLauncher<Intent> getAddExpenseLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddExpenseActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddExpenseActivityResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result == null || result.getResultCode() != RESULT_OK || result.getData() == null) {
                    return;
                }
                Expense expense = (Expense) result.getData().getSerializableExtra(AddExpenseActivity.EXPENSE_KEY);
                if (expense == null) {
                    return;
                }
                if (ADD_ACTION.equals(result.getData().getStringExtra(ACTION_KEY))) {
                    expenseService.insert(expense, getInsertCallback());
                } else if (UPDATE_ACTION.equals(result.getData().getStringExtra(ACTION_KEY)) && result.getData().hasExtra(UPDATED_POSITION_KEY)) {
                    int position = result.getData().getIntExtra(UPDATED_POSITION_KEY, 0);
                    expenses.get(position).setCategory(expense.getCategory());
                    expenses.get(position).setAmount(expense.getAmount());
                    expenses.get(position).setDate(expense.getDate());
                    expenses.get(position).setDescription(expense.getDescription());
                    notifyAdapter();
                }
            }
        };
    }

    private void initComponents() {
        lvExpenses = findViewById(R.id.main_lv_expenses);
        fabAddExpense = findViewById(R.id.main_fab_add_expense);
        addAdapter();
        fabAddExpense.setOnClickListener(addExpenseEventListener());
        lvExpenses.setOnItemClickListener(getItemClickListener());
    }

    private AdapterView.OnItemClickListener getItemClickListener() {
        return new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                intent.putExtra(AddExpenseActivity.EXPENSE_KEY, expenses.get(position));
                intent.putExtra(ACTION_KEY, UPDATE_ACTION);
                intent.putExtra(UPDATED_POSITION_KEY, position);
                addExpenseLauncher.launch(intent);
            }
        };
    }

    private View.OnClickListener addExpenseEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                intent.putExtra(ACTION_KEY, ADD_ACTION);
                addExpenseLauncher.launch(intent);
            }
        };
    }

    private void addAdapter() {
        ExpenseAdapter adapter = new ExpenseAdapter(getApplicationContext(), R.layout.lv_expense_row,
                expenses, getLayoutInflater());
        lvExpenses.setAdapter(adapter);
    }

    private void notifyAdapter() {
        ExpenseAdapter adapter = (ExpenseAdapter) lvExpenses.getAdapter();
        adapter.notifyDataSetChanged();
    }
}