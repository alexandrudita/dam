package com.example.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.damapp.model.Expense;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private FloatingActionButton fabAddExpense;

    private ActivityResultLauncher<Intent> addExpenseLauncher;
    private List<Expense> expenses = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        configNavigation();
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(getItemSelected());
        fabAddExpense = findViewById(R.id.main_fab);
        fabAddExpense.setOnClickListener(getAddExpenseEvent());

        addExpenseLauncher = registerAddExpenseLauncher();
    }

    private View.OnClickListener getAddExpenseEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddExpenseActivity.class);
                addExpenseLauncher.launch(intent);
            }
        };
    }

    private ActivityResultLauncher<Intent> registerAddExpenseLauncher() {

        ActivityResultCallback<ActivityResult> callback = getAddExpenseResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddExpenseResultCallback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Expense expense = (Expense) result.getData().getSerializableExtra(AddExpenseActivity.EXPENSE_KEY);
                    Toast.makeText(getApplicationContext(), expense.toString(), Toast.LENGTH_LONG).show();
                    expenses.add(expense);
                }
            }
        };
    }

    private NavigationView.OnNavigationItemSelectedListener getItemSelected() {
        return new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(
                    @NonNull MenuItem item) {
                if (item.getItemId() == R.id.nav_home) {
                    Toast.makeText(getApplicationContext(),
                                    R.string.home_is_selected,
                                    Toast.LENGTH_SHORT)
                            .show();
                } else if (item.getItemId() == R.id.nav_contact) {
                    Toast.makeText(getApplicationContext(),
                                    R.string.contact_is_selected,
                                    Toast.LENGTH_SHORT)
                            .show();
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        };
    }

    private void configNavigation() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        toggle.syncState();
    }
}