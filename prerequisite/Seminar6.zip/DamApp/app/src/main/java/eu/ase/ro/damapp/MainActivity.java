package eu.ase.ro.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapp.util.BankAccount;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fabAdd;
    private ListView lvAccounts;

    private ActivityResultLauncher<Intent> addLauncher;

    private List<BankAccount> bankAccounts = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
        addLauncher = registerAddLauncher();
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 10, 2023, "ING"));
        bankAccounts.add(new BankAccount("Dita Alexandru",
                1234567890123456L, 3, 2022, "BRD"));
    }

    private void initComponents() {
        fabAdd = findViewById(R.id.main_fab_add);
        lvAccounts = findViewById(R.id.main_lv_bank_accounts);

        fabAdd.setOnClickListener(getAddEvent());
        ArrayAdapter<BankAccount> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, bankAccounts);
        lvAccounts.setAdapter(adapter);
    }

    private View.OnClickListener getAddEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                addLauncher.launch(intent);
            }
        };
    }

    private ActivityResultLauncher<Intent> registerAddLauncher() {
        ActivityResultCallback<ActivityResult> callback = getAddBankAccountResultCallaback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getAddBankAccountResultCallaback() {
        return new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    BankAccount account = (BankAccount) result.getData().getSerializableExtra(AddActivity.BANK_ACCOUNT_KEY);
                    bankAccounts.add(account);
                    notifyAdapter();
                }
            }
        };
    }

    private void notifyAdapter() {
        ArrayAdapter<BankAccount> adapter = (ArrayAdapter<BankAccount>) lvAccounts.getAdapter();
        adapter.notifyDataSetChanged();
    }
}