package eu.ase.ro.damapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import eu.ase.ro.damapp.util.Student;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fabAdd;
    private ListView lvStudents;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
    }

    private void notifyLvStudentsAdapter() {
        ArrayAdapter<Student> adapter = (ArrayAdapter<Student>) lvStudents.getAdapter();
        adapter.notifyDataSetChanged();
    }

    private void initComponents() {
        //initializare variabila
        fabAdd = findViewById(R.id.main_fab_add);
        //atasare evenimente
        fabAdd.setOnClickListener(getAddEventListener());

        lvStudents = findViewById(R.id.main_lv_students);
    }

    private View.OnClickListener getAddEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //atunci cand dau click pe buton
                //deschidere activitate
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivity(intent);
            }
        };
    }
}