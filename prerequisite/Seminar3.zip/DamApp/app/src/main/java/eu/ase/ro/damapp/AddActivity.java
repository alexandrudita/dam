package eu.ase.ro.damapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class AddActivity extends AppCompatActivity {

    private TextInputEditText tietName;
    private TextInputEditText tietEnrollmentDate;
    private Spinner spnFaculty;
    private RadioGroup rgStudyType;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //initializare componente vizuale
        initComponents();
    }

    private void initComponents() {
        tietName = findViewById(R.id.add_tiet_name);
        tietEnrollmentDate = findViewById(R.id.add_tiet_enrollment_date);
        spnFaculty = findViewById(R.id.add_spn_faculty);
        rgStudyType = findViewById(R.id.add_rg_study_type);
        btnSave = findViewById(R.id.add_btn_save);
    }
}