package eu.ase.ro.damapp.util;

public enum StudyType {

    FULL_TIME, DISTANCE
}
